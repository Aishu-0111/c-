﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS.Entities;
using HRDS.Exceptions;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace HRDS.DataAccessLayer
{
    public class EmployeeDAL
    {
        public static List<Employee> employeeList = new List<Employee>();

        public bool AddEmployeeDAL(Employee objEmployee)
        {
            bool employeeAdded = false;
            try
            {

                employeeList.Add(objEmployee);
                employeeAdded = true;

            }
            catch(SystemException ex)
            {
                throw new HRDSException(ex.Message);
            }
            return employeeAdded;
        }

        public bool UpdateEmployeeDAL(Employee updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                for (int i = 0; i < employeeList.Count; i++)
                {
                    if (employeeList[i].Id == updateEmployee.Id)
                    {
                        employeeList[i].Name = updateEmployee.Name;
                        employeeList[i].DesignationId = updateEmployee.DesignationId;
                        employeeList[i].DepartmentId = updateEmployee.DepartmentId;
                        employeeUpdated = true;
                        return employeeUpdated;
                    }
                }
            }
            catch (SystemException ex)
            {

                throw new HRDSException(ex.Message);
            }
            return employeeUpdated;
        }

        public bool DeleteEmployeeDAL(int deleteEmployeeId)
        {
            bool employeeDeleted = false;
            try
            {
                Employee employee = employeeList.Find(emp => emp.Id == deleteEmployeeId);
                employeeList.Remove(employee);
                employeeDeleted = true;
                return employeeDeleted;
            }
            catch (SystemException ex)
            {

                throw new HRDSException(ex.Message);
            }
            
        }

        public Employee SearchEmployeeDAL(int employeeId)
        {
            Employee searchEmployee = null;
            try
            {
                searchEmployee = employeeList.Find(employee => employee.Id == searchEmployee.Id);
                //return searchEmployee;
            }
            catch (SystemException ex)
            {

                throw new HRDSException(ex.Message);
            }
            return searchEmployee;
        }

        public List<Employee> GetAllEmployeeDAL()
        {
            return employeeList;
        }

        public void SerializeEmployeeDAL()
        {
            FileStream objFS = new FileStream(@"D:\ForSerial\BinarySer.dat", FileMode.Create, FileAccess.Write, FileShare.Read);
            BinaryFormatter objBinF = new BinaryFormatter();
            objBinF.Serialize(objFS, employeeList);
            objFS.Close();
        }
        public List<Employee> DeSerializeEmployeeDAL()
        {
            FileStream objFS = new FileStream(@"D:\ForSerial\BinarySer.dat", FileMode.Open, FileAccess.Read, FileShare.Read);
            BinaryFormatter objBinF = new BinaryFormatter();
            List<Employee> objEmployeesNew = objBinF.Deserialize(objFS) as List<Employee>;
            objFS.Close();
            return objEmployeesNew;
        }
    }
}
