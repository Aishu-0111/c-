﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;//for using regular expression for validation
using Route.Entites; //reference added and using its entites
using Route.Exceptions;//reference added and using custom Exception
using Route.DataAccessLayer;//reference added and using Data Access Layer data member and data functions 
namespace Route.BusinessLayer
{
    public class RouteBL
    {
        private static bool ValidateRoute(RouteEntites route)
        {
            StringBuilder sb = new StringBuilder();
            bool isvalid = true;
            if(route.Routeid <= 10 || route.Routeid > 1000)
            {
                isvalid = false;
                sb.Append("\nRouteId should br 2 to 3 digits long (for ex.41,123).");
            }
            if (route.BusType.ToUpper() != "AC" && route.BusType.ToUpper() !="NON-AC" )
            {
                isvalid = false;
                sb.Append("\nBus Type should be 'AC' or 'Non-AC'.");
            }
            if (!Regex.Match(route.Capacity.ToString(), "^[0-9]*$").Success)
            {
                isvalid = false;
                sb.Append("\nCapacity should be only in digits'.");
            }
            if (!Regex.Match(route.Fare.ToString(), "^[0-9]*$").Success)
            {
                isvalid = false;
                sb.Append("\nFare should be only in digits.");
            }
            if (!Regex.Match(route.BusNo.ToUpper(), "^[A-Z][A-Z]-[0-9][0-9]-[A-Z][A-Z]-[0-9][0-9][0-9][0-9]$").Success)
            {
                isvalid = false;
                sb.Append("\nBus Number should have first 2 alphabets,hyphen,2 digit,hyphen,2 alphabets,hyphen then 4 digit. ");
            }
            if (!Regex.Match(route.RouteFrom, "^[a-zA-Z]*$").Success)
            {
                isvalid = false;
                sb.Append("\nRoute From: accepts only Alphabets ");
            }
            if (!Regex.Match(route.RouteTo, "^[a-zA-Z]*$").Success)
            {
                isvalid = false;
                sb.Append("\nRoute To: accept only Alphabets");
            }
            if (route.Fare.ToString()== string.Empty || route.Routeid.ToString() == string.Empty || route.Capacity.ToString() == string.Empty)
            {
                isvalid = false;
                sb.Append("\nRouteid, Fare, Capacity field cannot be left Empty plese enter a Valid Value.");
            }
            if(route.BusNo == string.Empty || route.BusType == string.Empty || route.RouteFrom == string.Empty || route.RouteTo == string.Empty)
            {
                isvalid = false;
                sb.Append("\nRoute From , Route To , Bus Number , Bus Type field cannot be Empty plese enter a Valid Value.");
            }
            if (isvalid == false)
            {
                throw new RouteException(sb.ToString());
            }
            return isvalid;
        }

        public static bool AddRouteBL(RouteEntites newRoute)
        {
            bool isvalid = false;
            try
            {
                if (ValidateRoute(newRoute))
                {
                    RouteDAL routeDAL = new RouteDAL();
                    isvalid = routeDAL.AddRouteDAL(newRoute);
                }
            }
            catch (RouteException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw e;
            }
            return isvalid;
        }

        public static bool UpdateRouteBL(RouteEntites newRoute)
        {
            bool isvalid = false;
            try
            {
                if (ValidateRoute(newRoute))
                {
                    RouteDAL routeDAL = new RouteDAL();
                    isvalid = routeDAL.UpdateRouteDAL(newRoute);
                }
            }
            catch (RouteException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw e;
            }
            return isvalid;
        }

        public static bool DeleteRouteBL(int deleteRouteId)
        {
            bool isvalid = false;
            try
            {
                if (deleteRouteId > 0)
                {
                    RouteDAL routeDAL = new RouteDAL();
                    isvalid = routeDAL.DeleteRouteDAL(deleteRouteId);
                }
            }
            catch (RouteException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw e;
            }
            return isvalid;
        }

        public static RouteEntites SearchRouteBL(int searchRouteId)
        {
            RouteEntites searchRoute = null;
            try
            {
                RouteDAL routeDAL = new RouteDAL();
                searchRoute = routeDAL.SearchRouteDAL(searchRouteId);
            }
            catch (RouteException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw e;
            }
            return searchRoute;
        }

        public static List<RouteEntites> GetAllRoutesBL()
        {
            List<RouteEntites> routelist = null;
            try
            {
                RouteDAL routeDAL = new RouteDAL();
                routelist = routeDAL.GetAllRouteDAL();
            }
            catch (RouteException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return routelist;
        }

        public static bool SerializationBL()
        {
            bool serial = false;
            RouteDAL objDAL = new RouteDAL();
            serial = objDAL.SerializationDAL();
            return serial;
        }

        public static List<RouteEntites> DeserializationBL()
        {
            RouteDAL objDAL = new RouteDAL();
            List<RouteEntites> deserial = objDAL.DeserializationDAL();
            return deserial;
        }
    }
}
