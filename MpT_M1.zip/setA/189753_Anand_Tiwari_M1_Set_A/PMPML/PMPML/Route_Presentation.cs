﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Route.Entites; //reference added and using its entites
using Route.Exceptions;//reference added and using custom Exception
using Route.DataAccessLayer;//reference added and using Data Access Layer data member and data functions 
using Route.BusinessLayer;//reference added and using Business Layer data member and data functions 
namespace PMPML
{
    class Route_Presentation
    {
        static void Main(string[] args)
        {
            int choice;
            while (true)
            {
                PrintMenu();
                try {
                    Console.WriteLine("Enter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddRoute();
                            break;
                        case 2:
                            ListAllRoutes();
                            break;
                        case 3:
                            SearchRouteByID();
                            break;
                        case 4:
                            UpdateRoute();
                            break;
                        case 5:
                            DeleteRoute();
                            break;
                        case 6:
                            Serialization();
                            break;
                        case 7:
                            Deserialization();
                            break;
                        case 8:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                }
                    catch(RouteException )
                    {
                    throw;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
            }
        }

        private static void AddRoute()
        {
            try
            {
                RouteEntites newRoute = new RouteEntites();
                Console.WriteLine("Enter RouteID :");
                newRoute.Routeid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Route From :");
                newRoute.RouteFrom = Console.ReadLine();
                Console.WriteLine("Enter Route To :");
                newRoute.RouteTo = Console.ReadLine();
                Console.WriteLine("Enter Bus No :");
                newRoute.BusNo = Console.ReadLine();
                Console.WriteLine("Enter Bus Type :");
                newRoute.BusType = Console.ReadLine();
                Console.WriteLine("Enter Capacity :");
                newRoute.Capacity = Convert.ToInt32( Console.ReadLine());
                Console.WriteLine("Enter Fare :");
                newRoute.Fare = Convert.ToDouble(Console.ReadLine());

                bool routeAdded = RouteBL.AddRouteBL(newRoute);
                if (routeAdded)
                    Console.WriteLine("Route Added");
                else
                    Console.WriteLine("Route not Added");
            }
            catch (RouteException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateRoute()
        {
            try
            {
                int updateRouteID;
                Console.WriteLine("Enter RouteID to Update Details:");
                updateRouteID = Convert.ToInt32(Console.ReadLine());
                RouteEntites updatedRoute = RouteBL.SearchRouteBL(updateRouteID);
                if (updatedRoute != null)
                {                   
                    Console.WriteLine("Update Route From :");
                    updatedRoute.RouteFrom = Console.ReadLine();
                    Console.WriteLine("Update Route To :");
                    updatedRoute.RouteTo = Console.ReadLine();
                    Console.WriteLine("Update Bus No :");
                    updatedRoute.BusNo = Console.ReadLine();
                    Console.WriteLine("Update Bus Type :");
                    updatedRoute.BusType = Console.ReadLine();
                    Console.WriteLine("Update Capacity :");
                    updatedRoute.Capacity = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Update Fare :");
                    updatedRoute.Fare = Convert.ToDouble(Console.ReadLine());


                    bool routeUpdated = RouteBL.UpdateRouteBL(updatedRoute);
                    if (routeUpdated)
                        Console.WriteLine("Route Details Updated");
                    else
                        Console.WriteLine("Route Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Route Details Available");
                }


            }
            catch (RouteException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeleteRoute()
        {
            try
            {
                int deleteRouteID;
                Console.WriteLine("Enter RouteID to Delete:");
                deleteRouteID = Convert.ToInt32(Console.ReadLine());
                RouteEntites deleteRoute = RouteBL.SearchRouteBL(deleteRouteID);
                if (deleteRoute != null)
                {
                    bool routedeleted = RouteBL.DeleteRouteBL(deleteRouteID);
                    if (routedeleted)
                        Console.WriteLine("Route Deleted");
                    else
                        Console.WriteLine("Route not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Route Details Available");
                }


            }
            catch (RouteException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchRouteByID()
        {
            try
            {
                int routeID;
                Console.WriteLine("Enter RouteID to Search:");
                routeID = Convert.ToInt32(Console.ReadLine());
                RouteEntites route = RouteBL.SearchRouteBL(routeID);
                if (route != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("RouteID\t\tRoute From\t\tRoute To\t\tBus No\t\tBus Type\t\tCapacity\t\tFare");
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("{0}\t\t{1}\t\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}", route.Routeid, route.RouteFrom, route.RouteTo, route.BusNo.ToUpper(), route.BusType.ToUpper(), route.Capacity,route.Fare);
                    Console.WriteLine("==============================================================================");
                }
                else
                {
                    Console.WriteLine("No Route Details Available");
                }

            }
            catch (RouteException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        
        private static void ListAllRoutes()
        {
            try
            {
                List<RouteEntites> routeList = RouteBL.GetAllRoutesBL();
                if (routeList != null)
                {
                    Console.WriteLine("=======================================================================================================================================================");
                    Console.WriteLine("RouteID\t\tRoute From\t\tRoute To\t\tBus No\t\tBus Type\t\tCapacity\t\tFare");
                    Console.WriteLine("==================================================================================================================================");
                    foreach (RouteEntites route in routeList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t\t{2}\t\t{3}\t\t{4}\t\t\t{5}\t\t{6}", route.Routeid, route.RouteFrom, route.RouteTo, route.BusNo.ToUpper(), route.BusType.ToUpper(), route.Capacity, route.Fare);
                    }
                    Console.WriteLine("========================================================================================================================================");

                }
                else
                {
                    Console.WriteLine("No Route Details Available");
                }
            }
            catch (RouteException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void Serialization()
        {
            bool guest = RouteBL.SerializationBL();
            if (guest == true)
            {
                Console.WriteLine("\n---------Binary Serialization Done----------------\n");
            }
            else
            {
                Console.WriteLine("\n---------Binary Serialization Failed----------------\n");
            }
        }

        private static void Deserialization()
        {
            Console.WriteLine("\n-------------------------------Deserialization-------------------------------------------------------------------------------");
            try
            {
                List<RouteEntites> objguestlist = RouteBL.DeserializationBL();
                objguestlist.ForEach(item => Console.WriteLine("\nRouteID: {0}\tRoute From: {1}\tRoute To: {2}\tBus No: {3}\tBus Type: {4}\tCapacity {5}\tFare: {6}", item.Routeid, item.RouteFrom, item.RouteTo, item.BusNo.ToUpper(), item.BusType.ToUpper(), item.Capacity, item.Fare));
            }
            catch (RouteException e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n=======================Route Menu==========================");
            Console.WriteLine("1. Add Route");
            Console.WriteLine("2. List All Routes");
            Console.WriteLine("3. Search Route by ID");
            Console.WriteLine("4. Update Route");
            Console.WriteLine("5. Delete Route");
            Console.WriteLine("6. Serialization");
            Console.WriteLine("7. Deserialization");
            Console.WriteLine("8. Exit");
            Console.WriteLine("==============================================================================\n");

        }

    }
}
