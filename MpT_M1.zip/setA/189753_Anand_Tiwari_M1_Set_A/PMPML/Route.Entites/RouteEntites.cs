﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Route.Entites
{
    [Serializable] //to make the class serializable 
    public class RouteEntites
    {
        //initialization of variable assign to there specific data type.
        private int routeid, capacity;
        private double fare;
        private string routeFrom, routeTo, busNo, busType;

        //Properties of the variables above
        public int Routeid { get {return routeid; } set { routeid = value; } }
        public int Capacity { get {return capacity; } set { capacity = value; } }
        public double Fare { get {return fare; } set { fare = value; } }

        public string RouteFrom { get {return routeFrom; } set { routeFrom = value; } }
        public string RouteTo { get {return routeTo; } set { routeTo = value; } }
        public string BusNo { get {return busNo; } set { busNo = value; } }
        public string BusType { get {return busType; } set { busType = value; } }

        //constructor to initialize values of variable to 0 or null as the program start
        public RouteEntites()
        {
            Routeid = Capacity = 0;
            Fare =0;
            RouteFrom = RouteTo = BusNo = BusType = string.Empty;
        }
    }
}
