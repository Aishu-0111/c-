﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Route.Exceptions
{
    public class RouteException : ApplicationException //Custom Exception
    {
        public RouteException():base ()//Custom Exception default constructor
        {

        }
        public RouteException(string Message):base (Message)//Custom Exception parameterised constructor "string Message"
        {

        }
        public RouteException(string Message,Exception innerException) : base(Message,innerException)//Custom Exception parameterised constructor "string Message" and "Exception innerException"
        {

        }
    }
}
