﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Route.Entites; //reference added and using its entites
using Route.Exceptions;//reference added and using custom Exception
using System.IO; //Input / output file stream
using System.Runtime.Serialization.Formatters.Binary;//Binary serialization
namespace Route.DataAccessLayer
{
    public class RouteDAL
    {
        public static List<RouteEntites> routeList = new List<RouteEntites>(); //genric list<> of RouteEntity class

        public bool AddRouteDAL(RouteEntites newRoute)
        {
            bool isvalid = false;
            try
            {
                routeList.Add(newRoute);
                isvalid = true;
            }
            catch (SystemException e)
            {
                throw new RouteException(e.Message);
            }
            return isvalid;
        } //Add Route in list<> using .add() inbuilt functn

        public bool UpdateRouteDAL(RouteEntites updateRoute)
        {
            bool RouteUpdated = false;
            try
            {
                for (int i = 0; i < routeList.Count; i++)
                {
                    if (routeList[i].Routeid == updateRoute.Routeid)
                    {
                        updateRoute.RouteFrom = routeList[i].RouteFrom;
                        updateRoute.RouteTo = routeList[i].RouteTo;
                        updateRoute.BusNo = routeList[i].BusNo;
                        updateRoute.BusType = routeList[i].BusType;
                        updateRoute.Capacity = routeList[i].Capacity;
                        updateRoute.Fare = routeList[i].Fare;
                        RouteUpdated = true;
                    }
                }

            }
            catch (SystemException e)
            {
                throw new RouteException(e.Message);
            }
            return RouteUpdated;
        }//update Route in list<> by initializing array[i] loop

        public bool DeleteRouteDAL(int deleteRouteID)
        {
            bool RoutreDeleted = false;
            try
            {
                RouteEntites deleteroute = routeList.Find(find => find.Routeid == deleteRouteID);

                if (deleteroute != null)
                {
                    routeList.Remove(deleteroute);
                    RoutreDeleted = true;
                }
            }
            catch (Exception ex)
            {
                throw new RouteException(ex.Message);
            }
            return RoutreDeleted;

        }//Delete Route in list<> using .Remove() inbuilt functn

        public RouteEntites SearchRouteDAL(int searchRouteID)
        {
            RouteEntites searchRoute = null;
            try
            {
                searchRoute = routeList.Find(find => find.Routeid == searchRouteID);
            }
            catch (SystemException e)
            {
                throw new RouteException(e.Message);
            }
            return searchRoute;
        }//search Route in list<> using lambda "=>" inbuilt functn

        public List<RouteEntites> GetAllRouteDAL()
        {
            return routeList;
        }//returning list<>

        public bool SerializationDAL()
        {
            bool serializationRoute = false;
            try
            {
                FileStream stream = new FileStream("Routes.bat", FileMode.Create, FileAccess.Write); //file stream object
                BinaryFormatter binary = new BinaryFormatter(); //binary formatter 
                binary.Serialize(stream, routeList); // serializing routelist to file Route.bat (file will be found in bin folder)
                stream.Close();
                serializationRoute = true;
            }
            catch (RouteException e)
            {
                Console.WriteLine(e.Message);
            }
            return serializationRoute;
        }//Binary Serialization

        public List<RouteEntites> DeserializationDAL()
        {

            FileStream stream = new FileStream(@"Routes.bat", FileMode.Open, FileAccess.Read); // file stream object
            BinaryFormatter binary = new BinaryFormatter(); // binary formatter
            List<RouteEntites> objRoute = binary.Deserialize(stream) as List<RouteEntites>;//
            stream.Close();
            return objRoute;

        }//Binary Deserialization
    }
}
