﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMPL_ENTITY
{
    [Serializable]
    public class PMPLEn
    {
        int routeid;
        string routefrom;
        string routeto;
        string busno;
        string bustype;
        string capacity;
        string fare;

        public int RouteID
        {
            get
            {
                return routeid;
            }
            set
            {
                routeid = value;
            }
        }

        public string RouteFrom
        {
            get
            {
                return routefrom;
            }
            set
            {
                routefrom = value;
            }
        }

        public string RouteTo
        {
            get
            {
                return routeto;
            }
            set
            {
                routeto = value;
            }
        }

        public string BusNo
        {
            get
            {
                return busno;
            }
            set
            {
                busno = value;
            }
        }

        public string BusType
        {
            get
            {
                return bustype;
            }
            set
            {
                bustype = value;
            }
        }

        public string Capacity
        {
            get
            {
                return capacity;
            }
            set
            {
                capacity = value;
            }
        }

        public string Fare
        {
            get
            {
                return fare;
            }
            set
            {
                fare = value;
            }
        }

    }
}
