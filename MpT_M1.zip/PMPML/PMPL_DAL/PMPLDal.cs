﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using PMPL_ENTITY;
using PMPL_EXCEPTIONHANDLING;

namespace PMPL_DAL
{
    public class PMPLDal
    {
        public static List<PMPLEn> buslist = new List<PMPLEn>();

        // Adding data to the list
        public bool AddRouteDAL(PMPLEn addroute)
        {
            bool routeadded = false;
            try
            {
                buslist.Add(addroute);
                routeadded = true;
            }
            catch (SystemException ex)
            {
                throw new PMPLException(ex.Message);
            }
            return routeadded;
        }
        
        // Updating data in the list
        public bool UpdateRouteDAL(PMPLEn updateroute)
        {
            bool routeupdated = false;
            try
            {
                for (int i = 0; i < buslist.Count; i++)
                {
                    if (buslist[i].RouteID == updateroute.RouteID)
                    {
                        updateroute.RouteFrom = buslist[i].RouteFrom;
                        updateroute.RouteTo = buslist[i].RouteTo;
                        updateroute.BusNo = buslist[i].BusNo;
                        updateroute.BusType = buslist[i].BusType;
                        updateroute.Capacity = buslist[i].Capacity;
                        updateroute.Fare = buslist[i].Fare;
                        routeupdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PMPLException(ex.Message);
            }
            return routeupdated;
        }

        // Deleting data in the list
        public bool DeleteRouteDAL(int deleterouteid)
        {
            bool routedeleted = false;
            try
            {
                PMPLEn objentity = buslist.Find(bus => bus.RouteID == deleterouteid);
                buslist.Remove(objentity);
                routedeleted = true;
            }
            catch (SystemException ex)
            {
                throw new PMPLException(ex.Message);
            }
            return routedeleted;
        }

        // Searching data from the list
        public PMPLEn SearchRouteDAL(int searchrouteid)
        {
            PMPLEn routesearch = null;
            try
            {
                routesearch = buslist.Find(bus => bus.RouteID == searchrouteid);
            }
            catch (SystemException ex)
            {
                throw new PMPLException(ex.Message);
            }
            return routesearch;
        }

        //Serializing list items
        public void SerializeRouteDAL()
        {
            FileStream objfs = new FileStream(@"\serialize.dat",FileMode.OpenOrCreate,FileAccess.Write,FileShare.Read);
            BinaryFormatter objbinf = new BinaryFormatter();
            objbinf.Serialize(objfs, buslist);
            objfs.Close();
        }

        //De-Serializing into list items
        public List<PMPLEn> DeSerializeDAL()
        {
            FileStream objfs = new FileStream(@"\serialize.dat", FileMode.Open, FileAccess.Read, FileShare.Read);
            BinaryFormatter objbinf = new BinaryFormatter();
            List<PMPLEn> buslist = objbinf.Deserialize(objfs) as List<PMPLEn>;
            objfs.Close();
            return buslist;            
        }
    }
}
