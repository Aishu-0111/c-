﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMPL_EXCEPTIONHANDLING
{
    public class PMPLException : ApplicationException
    {
        public PMPLException() : base() 
        {

        }

        public PMPLException(string message) : base(message)
        {

        }

        public PMPLException(string msg , Exception innerexception) : base(msg , innerexception)
        {

        }
    }
}
