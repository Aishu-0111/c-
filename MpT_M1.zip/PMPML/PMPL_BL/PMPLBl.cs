﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMPL_DAL;
using PMPL_EXCEPTIONHANDLING;
using PMPL_ENTITY;
using System.Text.RegularExpressions;

namespace PMPL_BL
{
    public class PMPLBl
    {
        //Validatind data entered by the Service Engineer
        private static bool Validate(PMPLEn objentity)
        {
            StringBuilder sb = new StringBuilder();
            bool validateroute = true;

            if (objentity.RouteFrom == " ")
            {
                validateroute = false;
                sb.Append(Environment.NewLine + "From route cannot be blank!!");
            }

            if (objentity.RouteTo == " ")
            {
                validateroute = false;
                sb.Append(Environment.NewLine + "To route cannot be blank!!");
            }

            if (objentity.BusNo == " ")
            {
                validateroute = false;
                sb.Append(Environment.NewLine + "Bus number cannot be blank!!");
            }

            if ((objentity.BusType != "AC") && (objentity.BusType != "Non-AC")&&(objentity.BusType == " "))
            {
                validateroute = false;
                sb.Append(Environment.NewLine + "Bus type should be only AC or Non-AC and cannot be blank!!");
            }

            if ((!Regex.IsMatch(objentity.Capacity,@"^[0-9]+$")) && objentity.Capacity == "")
            {
                validateroute = false;
                sb.Append(Environment.NewLine + "Bus capacity should contain only digits and cannot be blank!!");
            }

            if ((!Regex.IsMatch(objentity.Fare, @"^[0-9]+$")) && objentity.Fare == "")
            {
                validateroute = false;
                sb.Append(Environment.NewLine + "Bus fare should contain only digits and cannot be blank!!");
            }

            if (validateroute == false)
            {
                throw new PMPLException(sb.ToString());
            }
            return validateroute; 
        }

        //Providing data to the data access layer
        public static bool AddrouteBL(PMPLEn addroute)
        {
            bool routeadded = false;
            try
            {
                if (Validate(addroute))
                {
                    PMPLDal objadd = new PMPLDal();
                    objadd.AddRouteDAL(addroute);
                    routeadded = true;
                }
            }
            catch (PMPLException ex)
            {
                throw ex;
            }
            return routeadded;
        }

        //Updating data in the data access layer
        public static bool UpdaterouteBL(PMPLEn updateroute)
        {
            bool routeupdated = false;
            try
            {
                if (Validate(updateroute))
                {
                    PMPLDal objadd = new PMPLDal();
                    objadd.UpdateRouteDAL(updateroute);
                    routeupdated = true;
                }
            }
            catch (PMPLException ex)
            {
                throw ex;
            }
            return routeupdated;
        }

        //Deleting data from the data access layer
        public static bool DeleterouteBL(int delrouteId)
        {
            bool routedeleted = false;
            try
            {
                if (delrouteId > 0)
                {
                    PMPLDal objadd = new PMPLDal();
                    objadd.DeleteRouteDAL(delrouteId);
                    routedeleted = true;
                }               
            }
            catch (PMPLException ex)
            {
                throw ex;
            }
            return routedeleted;
        }

        //Searching data from the data access layer
        public static PMPLEn SearchrouteBL(int searchid)
        {
            PMPLEn objsearch = null;
            try
            {
                if (searchid > 0)
                {
                    PMPLDal objadd = new PMPLDal();
                    objsearch = objadd.SearchRouteDAL(searchid);                   
                }
            }
            catch (PMPLException ex)
            {
                throw ex;
            }
            return objsearch;
        }

        //Calling serialization function from data access layer
        public static void SerializeRouteBL()
        {
            PMPLDal objserilaize = new PMPLDal();
           objserilaize.SerializeRouteDAL();
        }

        //Calling De-serialization function from data access layer
        public static List<PMPLEn> DeSerializeBL()
        {
            List<PMPLEn> buslist = new List<PMPLEn>();
            PMPLDal objdeserialize = new PMPLDal();
            buslist = objdeserialize.DeSerializeDAL();
            return buslist;
        }
    }
}
