﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab12b
{
    class Program
    {
        static string sourcePath, destinationPath;
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Source File Name that you Want to copy :");
            sourcePath = Console.ReadLine();
            Console.WriteLine("Enter Destination File Name where you want to copy :");
            destinationPath = Console.ReadLine();
            CopyFileClass();
        }
        static void CopyFileClass()
        {
            string strFilePath = @"D:\file io" + sourcePath;
            string strFileDestinationPath = @"D:\file io" + destinationPath;
            if (File.Exists(strFileDestinationPath))
            {
                Console.WriteLine("The File Name Already Exists");
            }
            else if (!File.Exists(strFilePath))
            {
                Console.WriteLine("Source File not Exists");
            }
            else if (File.Exists(strFilePath))
            {
                File.Copy(strFilePath, strFileDestinationPath);
                if (File.Exists(strFileDestinationPath))
                {
                    Console.WriteLine("File Copied Successfully.");
                }
                else
                {
                    Console.WriteLine("File could not be Copied.");
                }
            }
            Console.ReadKey();
        }
    }
}
