﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employeelib
{
    public class Class1
    {
        int empID;
        int empsal;
        string empName;
        string empadd;
        string empCity;
        string empDept;

        public int Employeeid
        {
            get
            {
                return empID;
            }
            set
            {
                empID = value;
            }
        }

        public int EmployeeSal
        {
            get
            {
                return empsal;
            }
            set
            {
                empsal = value;
            }
        }

        public string EmployeeName
        {
            get
            {
                return empName;
            }
            set
            {
                empName = value;
            }
        }

        public string EmployeeAdd
        {
            get
            {
                return empadd;
            }
            set
            {
                empadd = value;
            }
        }

        public string EmployeeCity
        {
            get
            {
                return empCity;
            }
            set
            {
                empCity = value;
            }
        }

        public string EmployeeDept
        {
            get
            {
                return empDept;
            }
            set
            {
                empDept = value;
            }
        }
    }
}
