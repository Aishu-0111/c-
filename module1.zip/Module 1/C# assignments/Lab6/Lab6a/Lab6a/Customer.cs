﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6a
{
    class Customer
    {
        int custID;
        string custName;
        string add;
        string city;
        string phone;
        int creditLimit;

        public int CustID
        {
            get
            {
                return custID;
            }
            set
            {
                custID = value;
            }
        }

        public string CustName
        {
            get
            {
                return custName;
            }
            set
            {
                custName = value;
            }
        }

        public string Address
        {
            get
            {
                return add;
            }
            set
            {
                add = value;
            }
        }

        public string City
        {
            get
            {
                return city;
            }
            set
            {
                city = value;
            }
        }

        public string Phone
        {
            get
            {
                return phone;
            }
            set
            {
                phone = value;
            }
        }

        public int CreditLimit
        {
            get
            {
                return creditLimit;
            }
            set
            {
                creditLimit = value;
            }
        }

        public Customer()
        {
        }

        public Customer(int id, string name, string add, string city, string phoneno, int limit)
        {
            this.CustID = id;
            this.CustName = name;
            this.Address = add;
            this.City = city;
            this.Phone = phoneno;
            this.CreditLimit = limit;
            if (CreditLimit > 50000)
            {
                throw (new InvalidCreditLimitException("Error!!!"));
            }
            else
            {
                this.CreditLimit = limit;
                Console.WriteLine(CreditLimit);
            }
        }
    }
}
