﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Lab6b
{
    class ProductMock
    {
        public bool A = false;
        public int productid;
        public string productname;
        public double productprice;
        
        public int ProductID
        {
            get
            {
                return productid;
            }
            set
            {
                productid = value;
            }
        }
        
        public string ProductName
        {
            get
            {
                return productname;
            }
            set
            {
                productname = value;
            }
        }

        public double ProductPrice
        {
            get
            {
                return productprice;
            }
            set
            {
                productprice = value;
            }
        }

        public ProductMock()
        {
        }

        public ProductMock(int id, string name1, double price)
        {
            this.ProductID = id;
            this.ProductName = name1;
            this.ProductPrice = price;

            try
            {
                if (ProductID <= 0)
                {
                    throw new DataEntryException(" Enter id greater than 0 ");
                }
                else if (!Regex.IsMatch(productname, @"^[a-zA-Z0-9]+$"))
                {
                    throw new DataEntryException("Enter only digits and numbers for Product Name");
                }
                else if (ProductPrice <= 0)
                {
                    throw new DataEntryException("Enter Price greater than 0");
                }
                else if (ProductName == "")
                {
                    throw new DataEntryException("Product name should not be left blank");
                }
                else
                    A = true;
            }
            catch (DataEntryException ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }
    }
}
