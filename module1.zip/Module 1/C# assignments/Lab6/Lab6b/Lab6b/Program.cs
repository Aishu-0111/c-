﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6b
{
    class Program
    {
        public static int productid;
        public static string productname;
        public static double productprice;

        public void GetProductDetails()
        {
            ProductMock obj = new ProductMock(productid, productname, productprice);
            if (obj.A == true)
                DisplayDetails(obj);
        }

        public void DisplayDetails(ProductMock obj2)
        {
            Console.WriteLine("\nID is : " + obj2.ProductID);
            Console.WriteLine("Name is : " + obj2.ProductName);
            Console.WriteLine("Price is : " + obj2.ProductPrice);
        }

        static void Main(string[] args)
        {
            try
            {
                Program x = new Program();
                Console.WriteLine("enter product id: ");
                productid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter product Name: ");
                productname = Console.ReadLine();
                Console.WriteLine("enter product Price: ");
                productprice = Convert.ToDouble(Console.ReadLine());
                x.GetProductDetails();

            }
            catch (DataEntryException ex)

            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}

