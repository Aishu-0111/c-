﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4a
{
    abstract class Employee
    {
        public int empid
        {
            get;
            set;
        }

        public string empname
        {
            get;
            set;
        }

        public string add
        {
            get;
            set;
        }

        public string city
        {
            get;
            set;
        }

        public string dept
        {
            get;
            set;
        }

        public double salary
        {
            get;
            set;
        }

        public abstract double GetSalary();

        static void Main(string[] args)
        {
            ContractEmployee obj = new ContractEmployee();
            PermanentEmployee obj1 = new PermanentEmployee();
            Console.WriteLine("Select any one type of employee:\n");
            Console.WriteLine("Press 1 for Contract employee and Press 2 for Permanent employee");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.WriteLine("\n**Contract Employee Details**");
                    obj.GetData();
                    double csal = obj.GetSalary();
                    Console.WriteLine("Salary of Contract Employee is : " + csal);
                    break;

                case 2:
                    Console.WriteLine("\n**Permanent employee details**");
                    obj1.GetData();
                    double psal = obj1.GetSalary();
                    Console.WriteLine("Salary of Permanent Employee is : " + psal);
                    break;

                case 3:
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Inavlid Input");
                    break;
            }
            Console.ReadLine();
        }
        void GetData()
        {
            Console.WriteLine("\nEnter Employee Id :");
            empid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name :");
            empname = Console.ReadLine();
            Console.WriteLine("Enter Employee Address :");
            add = Console.ReadLine();
            Console.WriteLine("Enter Employee City :");
            city = Console.ReadLine();
            Console.WriteLine("Enter Employee Department :");
            dept = Console.ReadLine();
            Console.WriteLine("Enter Employee Salary :");
            salary = Convert.ToDouble(Console.ReadLine());
        }
    }
}
