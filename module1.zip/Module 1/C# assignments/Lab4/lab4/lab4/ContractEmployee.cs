﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4a
{
    class ContractEmployee : Employee 
    {
        public double Perks
        {
            get;
            set;
        }

        public override double GetSalary()
        {
            Console.WriteLine("Enter Perks:");
            Perks = Convert.ToInt32(Console.ReadLine());
            double result;
            result = salary + Perks;
            return result;
        }
    }
}
