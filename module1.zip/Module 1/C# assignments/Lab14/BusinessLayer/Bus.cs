﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAcess;
using HandlingEntities;
using HandlingExcepiton;

namespace BusinessLayer
{
    public class Bus
    {
        private static bool ValidateGuest(GuestEn guest)
        {
            StringBuilder sb = new StringBuilder();
            bool validGuest = true;
            if (guest.GID <= 0)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Invalid Guest ID");

            }
            if (guest.GName == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest Name Required");

            }
            if (guest.GContact.Length < 10)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (validGuest == false)
                throw new Handlingexception(sb.ToString());
            return validGuest;
        }

        public static bool AddGuestBL(GuestEn newGuest)
        {
            bool guestAdded = false;
            try
            {
                if (ValidateGuest(newGuest))
                {
                    Guest guestDAL = new Guest();
                    guestAdded = guestDAL.AddGuest(newGuest);
                }
            }
            catch (Handlingexception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return guestAdded;
        }

        public static bool DelGuestBL(int newGuest)
        {
            bool guestDeleted = false;
            try
            {
                if (newGuest > 0)
                {
                    Guest guestDAL = new Guest();
                    guestDeleted = guestDAL.DeleteGuest(newGuest);
                }
                else
                {
                    throw new Handlingexception("Invalid Guest ID");
                }
            }
            catch (Handlingexception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return guestDeleted;
        }

        public static bool UpdateGuestBL(GuestEn updateGuest)
        {
            bool guestUpdated = false;
            try
            {
                if (ValidateGuest(updateGuest))
                {
                    Guest guestDAL = new Guest();
                    guestUpdated = guestDAL.UpdateGuest(updateGuest);
                }
            }
            catch (Handlingexception)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return guestUpdated;
        }

        public static List<GuestEn> GetAllGuestsBL()
        {
            List<GuestEn> guestList = null;
            try
            {
                Guest guestDAL = new Guest();
                guestList = guestDAL.GetAllGuests();
            }
            catch (Handlingexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return guestList;
        }

        public static GuestEn SearchGuestBL(int searchGuestID)
        {
            GuestEn searchGuest = null;
            try
            {
                Guest guestDAL = new Guest();
                searchGuest = guestDAL.SearchGuest(searchGuestID);
            }
            catch (Handlingexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchGuest;

        }
    }
}
