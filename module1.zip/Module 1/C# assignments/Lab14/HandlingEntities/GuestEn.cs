﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandlingEntities
{
    public class GuestEn
    {
        int guestID;

        public int GID
        {
            get
            {
                return guestID;
            }
            set
            {
                guestID = value;
            }
        }

        string guestName;

        public string GName
        {
            get
            {
                return guestName;
            }
            set
            {
                guestName = value;
            }
        }

        string guestContactNumber;

        public string GContact
        {
            get
            {
                return guestContactNumber;
            }
            set
            {
                guestContactNumber = value;
            }
        }
 
        public GuestEn()
        {
            guestID = 0;
            guestName = string.Empty;
            guestContactNumber = string.Empty;
        }
    }
}

