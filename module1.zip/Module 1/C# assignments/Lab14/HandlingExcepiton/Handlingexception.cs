﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandlingExcepiton
{
    public class Handlingexception : ApplicationException
    {
        public Handlingexception()
            : base()
        {
        }

        public Handlingexception(string message)
            : base(message)
        {
        }

        public Handlingexception(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
