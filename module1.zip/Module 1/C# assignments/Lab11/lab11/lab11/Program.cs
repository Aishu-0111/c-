﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab11b
{
    class Program
    {
        static void Main(string[] args)
        {
            FileDownloader fd = new FileDownloader("Additional Demos_Generics.zip", "D:\\Aishu\\Lab2C\\M1\\CSharp\\Demos");
            fd.DownLoadComplete += new DownloadCompeteHandler(DownLoadComplete);
            fd.DownLoadResource();
            fd.OnDownLoadComplete();
            Console.ReadKey();
        }
        static void DownLoadComplete(int perc)
        {
            Console.SetCursorPosition(10, 10);
            Console.Write("Downloading {0} Percent Complete", perc);
            Console.ReadLine();
        }
    }
}
