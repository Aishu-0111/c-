﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab11a
{
    delegate void CreditHandler();
    class CreditCard
    {
        internal event CreditHandler makePayment;
        static int cLimit = 10000;
        int balAmt = cLimit;

        public CreditCard(int cno, string cname)
        {
        }

        public int GetBalance()
        {
            return balAmt;
        }

        public int GetCreditLimit()
        {
            return cLimit;
        }

        public void MakePayment(int paymentAmount)
        {
            if (paymentAmount <= balAmt)
            {
                balAmt = balAmt - paymentAmount;
                makePayment();
                Console.WriteLine("Updated Balance Is : " + balAmt);
                Console.ReadKey();
            }
            else
                Console.WriteLine("Transaction Failed");
            Console.ReadKey();
        }
    }
}

