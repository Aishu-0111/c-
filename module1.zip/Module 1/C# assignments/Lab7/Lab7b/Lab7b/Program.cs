﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using Lab7b;

namespace Lan7b
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Product p1 = new Product();
            ArrayList objal = new ArrayList();
            int choice;
            do
            {
                Console.WriteLine("\nPress 1 to Add product \nPress 2 to Search product \nPress 3 to Delete product \nPress 4 to Save in sorted order \nPress 5 to Quit");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            add();
                            break;
                        }
                    case 2:
                        {
                            Search();
                            break;
                        }
                    case 3:
                        {
                            Delete();
                            break;
                        }
                    case 4:
                        {
                            SaveInSorted();
                            break;
                        }
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Please enter valid input");
                        break;
                }
            } while (choice != 5);

            void add()
            {
                Console.WriteLine("Enter the number of product you want to add : ");
                int numproduct = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < numproduct; i++)
                {
                    Product objProduct = new Product();
                    Console.WriteLine("Enter Product Number : ");
                    objProduct.prodno = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Product Name : ");
                    objProduct.name = Console.ReadLine();
                    Console.WriteLine("Enter Product Rating : ");
                    objProduct.rate = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Product Stock : ");
                    objProduct.stock = Convert.ToInt32(Console.ReadLine());
                    objal.Add(objProduct);
                }
            }

            void Search()
            {
                int check;
                Console.WriteLine("\nEnter product number you want to Search : ");
                check = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < objal.Count; i++)
                {
                    Product objProduct = objal[i] as Product;
                    if (objProduct.prodno == check)
                    {
                        Console.WriteLine("Product Number :  " + objProduct.prodno + "\nProduct Name :   " + objProduct.name + "\nProduct Rating :  " + objProduct.rate + "\nProduct Stock :  " + objProduct.stock);
                    }
                    else
                    {
                        Console.WriteLine("Your record is ABSENT");
                    }
                }
            }

            void Delete()
            {
                int check;
                Console.WriteLine("\nEnter product number you want to delete : ");
                check = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < objal.Count; i++)
                {
                    Product objProduct = objal[i] as Product;
                    if (objProduct.prodno == check)
                    {
                        objal.Remove(objProduct);                      
                        Console.WriteLine("*Data removed successfully*");
                    }
                }
            }

            void SaveInSorted()
            {
                for (int i = 0; i < objal.Count; i++)
                {
                    Product objProduct = objal[i] as Product;
                    objal.Sort();
                    Console.WriteLine("Product Number :  " + objProduct.prodno + "\nProduct Name :   " + objProduct.name + "\nProduct Rating :  " + objProduct.rate + "\nProduct Stock :  " + objProduct.stock);
                    Console.ReadKey();
                }
            }
        }

    }
}
