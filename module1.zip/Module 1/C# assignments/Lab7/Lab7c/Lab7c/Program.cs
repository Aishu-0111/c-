﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;

namespace Lab7c
{
    class Program
    {
        public static List<Emp> employees = new List<Emp>();
        static void Main(string[] args)
        {
            Console.WriteLine("Enter details to be added in the list:-");
            get_details();
            display();
            Console.ReadLine();
        }

        public static void get_details()
        {
            Emp emp = new Emp();
            Console.WriteLine("Enter the employee number:");
            emp.Employee_Number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the employee name:");
            emp.E_Name = Console.ReadLine();
            Console.WriteLine("Enter the basic salary of the employee:");
            emp.Basic_Salary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the amount of the employee PF:");
            emp.E_PF = Convert.ToDouble(Console.ReadLine());
            employees.Add(emp);
        }

        public static void display()
        {
            foreach (Emp e in employees)
            {
                Console.WriteLine("Employee No: {0}, Name: {1}, Basic Salary: {2}, PF: {3}", e.Employee_Number, e.E_Name, e.Basic_Salary, e.E_PF);
            }
        }
    }
}
