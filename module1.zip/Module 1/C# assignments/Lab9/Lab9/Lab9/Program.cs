﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9
{
    class Program
    {
        static void Main(string[] args)
        {
            string key, value;
            char select;
            Dictionary<string, string> names = new Dictionary<string, string>();
            names.Add("1", "Aishu");
            names.Add("2", "Suji");
            names.Add("3", "Meghna");
            names.Add("4", "Siva_j");
            do
            {
                Console.WriteLine("Press 1 to Add \nPress 2 to Update \nPress 3 to Remove \nPress 4 to Display \nPress 5 to exit");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            add();
                            break;
                        }
                    case 2:
                        {
                            update();
                            break;
                        }
                    case 3:
                        {
                            delete();
                            break;
                        }
                    case 4:
                        {
                            display();
                            break;
                        }
                    case 5:
                        {
                            Environment.Exit(0);
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid input");
                            break;
                        }
                }
                Console.WriteLine("Press 'y' for contuining, else press 'n' ");
                select = Convert.ToChar(Console.ReadLine());
            } while (select == 'y');

            void add()
            {
                try
                {
                    Console.WriteLine("Enter key : ");
                    key = Console.ReadLine();
                    Console.WriteLine("Enter value : ");
                    value = Console.ReadLine();
                    foreach (KeyValuePair<string, string> check in names)
                    {
                        if (check.Key == key)
                        {
                            throw new Exceptionhandler("Entered key already exists in Directory");
                        }
                    }
                    names.Add(key, value);
                    Console.WriteLine("**KeyValue pair successfully added**");
                }
                catch (Exceptionhandler ex)
                {
                    Console.WriteLine(ex);
                }
            }

            void update()
            {
                Console.WriteLine("\nEnter index to Update : ");
                int index = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter value to update : ");
                string objValue = Console.ReadLine();
                string objKey = names.ElementAt(index).Key;
                names.Remove(objKey);
                names.Add(objKey, objValue);
                string b = names.ElementAt(index).Value;
                Console.WriteLine("**KeyValue pair successfully Updated**\n");
                Console.WriteLine(" Key = " + objKey + " Value = " + b);
            }

            void delete()
            {
                Console.WriteLine("Enter key to remove : ");
                string rkey = Console.ReadLine();
                names.Remove(rkey);
                Console.WriteLine("**KeyValue pair successfully Removed**\n");
            }

            void display()
            {
                Console.WriteLine("**List of names in Dictionary**\n");
                foreach (KeyValuePair<string, string> obj in names)
                {
                    Console.WriteLine(" key : " + obj.Key + " " + "   Value : " + obj.Value + "\n");
                }
            }
        }
    }
}