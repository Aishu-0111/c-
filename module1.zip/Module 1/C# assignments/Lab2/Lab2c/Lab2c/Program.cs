﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2c
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] ans = new string[3];
            for (int i = 0; i < ans.Length; i++)
            {       
                Console.WriteLine("\nEnter the name of city : " );
                ans[i] = Console.ReadLine();
            }
            Console.WriteLine("\n**List of Cities**\n");
            foreach ( var d in ans)
            {
                Console.WriteLine(d);
            }
            Console.ReadLine();
        }
    }
}
