﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2a
{
    public struct Structure
    {
        public int number;
    }

    class Program
    {
        static void Main(string[] args)
        {
            Structure objstruct;
            Console.WriteLine("Enter any number : ");
            objstruct.number = Convert.ToInt32(Console.ReadLine());
            int choice;
            Console.WriteLine("\nEnter 1 for square and Enter 2 for cube");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    square(objstruct.number);
                    break;
                case 2:
                    cube(objstruct.number);
                    break;
                default:
                    Console.WriteLine("\nEnter valid Choice.");
                    break;
            }
        }

        static void cube(int n)
        {
            Console.WriteLine("\nCube of " + n + " is " + (n * n * n));
            Console.ReadKey();
        }

        static void square(int n)
        {
            Console.WriteLine("\nSquare of " + n + " is " + (n * n));
            Console.ReadKey();
        }
    }
}
