﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3d
{
    public class Supplier
    {

        internal int supplierID;
        internal string supplierName;
        internal string city;
        internal string phoneNo;
        internal string email;

        internal void AcceptDetails(Supplier ob)
        {
            //assigning values through object of class 
            supplierID = ob.supplierID;
            supplierName = ob.supplierName;
            city = ob.city;
            phoneNo = ob.phoneNo;
            email = ob.email;
        }

        //TODO:  DisplayDetails with return type Supplier
        internal void DisplayDetails()
        {
            Console.WriteLine("===Supplier Details===");
            Console.WriteLine("Supplier ID :" + supplierID);
            Console.WriteLine("supplierName :" + supplierName);
            Console.WriteLine("city :" + city);
            Console.WriteLine("phoneNo :" + phoneNo);
            Console.WriteLine("email :" + email);
            Console.ReadLine();
        }
    }
}
