﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3a
{
    public class Participant
    {
        private int employeeid;
        private string Name;
        private static string Compname;
        private float foundationMarks;
        private float WebBasicMarks;
        private float dotNetMarks;
        private float TotalMarks = 300;
        private float obMarks;
       
        public int Employeeid
        {
            get
            {
                return employeeid;
            }
            set
            {
                employeeid = value;
            }
        }

        public string name
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }

        public string CName
        {
            get
            {
                return Compname;
            }
            set
            {
                Compname = value;
            }
        }

        public float WBMarks
        {
            get
            {
                return WebBasicMarks;
            }
            set
            {
                WebBasicMarks = value;
            }
        }

        public float FMarks
        {
            get
            {
                return foundationMarks;
            }
            set
            {
                foundationMarks= value;
            }
        }

        public float DNMarks
        {
            get
            {
                return dotNetMarks;
            }
            set
            {
                dotNetMarks = value;
            }
        }

        public Participant()
        {
        }

        public Participant(int employeeid,string Name,float foundationMarks,float WebBasicMarks,float dotNetMarks)
        {
            this.employeeid = employeeid;
            this.Name = Name;
            this.foundationMarks = foundationMarks;
            this.WebBasicMarks = WebBasicMarks;
            this.dotNetMarks = dotNetMarks;
        }

        static Participant()
        {
            Compname = "Corporate University";
            Console.WriteLine("Company Name : " +Compname);
        }

        public void ObtainedMarks()
        {
            obMarks = foundationMarks + WebBasicMarks + dotNetMarks;
            Console.WriteLine("The obtained marks : " +obMarks);
        }

        public void Percentage()
        {
            float percent = obMarks / TotalMarks *100 ;
            Console.WriteLine("Percentage : " + percent);
        }

    }
}
                                                                                               