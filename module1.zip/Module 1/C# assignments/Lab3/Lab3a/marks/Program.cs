﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab3a;

namespace marks
{
    class Program
    {
        static void Main(string[] args)
        {
            char choice;
            do
            {
                bool flag = true;
                Console.WriteLine("Enter Emp ID :");
                int empid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Emp Name : ");
                string name = Console.ReadLine();
                Console.WriteLine("Enter FoundationMarks : ");
                int fmarks = Convert.ToInt32(Console.ReadLine());
                if (fmarks < 0 || fmarks > 100) { flag = false; }
                Console.WriteLine("Enter WebBasicMarks : ");
                int wmarks = Convert.ToInt32(Console.ReadLine());
                if (wmarks < 0 || wmarks > 100) { flag = false; }
                Console.WriteLine("Enter DotNetMarks : ");
                int dmarks = Convert.ToInt32(Console.ReadLine());
                if (dmarks < 0 || dmarks > 100) { flag = false; }
                Lab3a.Participant objP = new Lab3a.Participant(empid, name, fmarks, dmarks, wmarks);
                if (flag == false)
                {
                    Console.WriteLine("Please Enter valid Marks");
                }
                else
                {
                    objP.ObtainedMarks();
                    objP.Percentage();                 
                }
                Console.WriteLine("Press 'y' to Continue and 'n' to Exit.");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y');
        }
    }
}
