﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3c
{
    class Program
    {
        static Carsarr objC = new Carsarr();
        static void Main(string[] args)
        {
            int choice;
            char c;
            do
            {
                Console.WriteLine("**Cars info**\n");
                Console.WriteLine("Press 1 to add car \nPress 2 to update car \nPress 3 to search car \nPress 4 to delete car \nPress 5 to view car \nPress 6 to quit \n ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Addcar();
                        break;
                    case 2:
                        Updatecar();
                        break;
                    case 3:
                        Searchcar();
                        break;
                    case 4:
                        Deletecar();
                        break;
                    case 5:
                        Getcar();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter Valid option");
                        Console.ReadLine();
                        break;
                }
                Console.WriteLine("Do you want to Continue? \nPress 'y' to Continue and 'n' to Exit.");
                c = Convert.ToChar(Console.ReadLine());
            } while (c == 'y');
        }

        static void Addcar()
       {
            string make;
            string model;
            string year;
            int saleprice;
            Console.WriteLine("**Enter Car Details**\n");
            Console.WriteLine("Enter make :");
            make = Console.ReadLine();
            Console.WriteLine("Enter model :");
            model = Console.ReadLine();
            Console.WriteLine("Enter year :");
            year = Console.ReadLine();
            Console.WriteLine("Enter Price :");
            saleprice = Convert.ToInt32(Console.ReadLine());
            Cars objCar = new Cars { Make = make, Model = model, Year = year, SalesPrice = saleprice };
            objC.Addcar(objCar);
        }

        static void Updatecar()
        {
            string make, model;
            string year;
            int saleprice;
            Console.WriteLine("Enter Car Details to Update\n");
            Console.WriteLine("Enter Make :");
            make = Console.ReadLine();
            Console.WriteLine("Enter Model :");
            model = Console.ReadLine();
            Console.WriteLine("Enter Year :");
            year = Console.ReadLine();
            Console.WriteLine("Enter sale Price:");
            saleprice = Convert.ToInt32(Console.ReadLine());
            Cars objCar = new Cars { Make = make, Model = model, Year = year, SalesPrice = saleprice };
            objC.Updatecar(objCar);
        }

        static void Deletecar()
        {
            string make;
            Console.WriteLine("Enter Car Details to Delete : \n");
            Console.WriteLine("Enter Make :");
            make = Console.ReadLine();
            objC.Deletecar(make);
        }

        static void Searchcar()
        {
            string make;
            Console.WriteLine("Enter Car Details to Search \n");
            Console.WriteLine("Enter Make :");
            make = Console.ReadLine();
            Cars objCar = objC.Searchcar(make);
            Console.WriteLine("Make : {0}, Model : {1}, Year : {2}, SalePrice :{3}", objCar.Make, objCar.Model, objCar.Year, objCar.SalesPrice);
        }

        static void Getcar()
        {
            Cars[] objCarArray = objC.Getcar();
            foreach (Cars objCar in objCarArray)
            {
                if (objCar != null)
                {
                    Console.WriteLine("Make : {0}, Model : {1}, Year : {2}, SalePrice :{3}", objCar.Make, objCar.Model, objCar.Year, objCar.SalesPrice);
                }

            }
        }       
    }
}
