﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Lab13f
{
    [Serializable]
    class Student :ISerializable
    {
        public int Rollno
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public string City
        {
            get;
            set;
        }

        public string Degree
        {
            get;
            set;
        }

        public Student(int rollno, string name, string city, string degree)
        {
            this.Rollno = rollno;
            this.Name = name;
            this.City = city;
            this.Degree = degree;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("rollno", this.Rollno);
            info.AddValue("name", this.Name);
            info.AddValue("city", this.City);
            info.AddValue("degree", this.Degree);
        }
    }
}
