﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Soap;

namespace lab13c
{
    class Program
    {
        static void Main(string[] args)
        {
            Contact contact1 = new Contact();
            Console.WriteLine("Enter Contact No:");
            contact1.ContactNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Contact Name:");
            contact1.ContactName = Console.ReadLine();
            Console.WriteLine("Enter Cell no:");
            contact1.PhoneNo = Console.ReadLine();

            try
            {
                FileStream objFS = new FileStream(@"D:\SoapSerialization.xml", FileMode.Create, FileAccess.Write, FileShare.Read);
                SoapFormatter objSoapF = new SoapFormatter();
                objSoapF.Serialize(objFS, contact1);
                objFS.Close();
                Console.WriteLine("Record Inserted");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            try
            {
                FileStream objFS = new FileStream(@"D:\SoapSerialization.xml", FileMode.Open, FileAccess.Read, FileShare.Read);
                SoapFormatter Soap = new SoapFormatter();
                Contact objNewCon = Soap.Deserialize(objFS) as Contact;
                objFS.Close();
                Console.WriteLine("**Soap DeSerialization**");
                Console.WriteLine("\n Employee Detail");
                Console.WriteLine("Contact NO : {0},  Contact NAME: {1},   Cell no: {2}", objNewCon.ContactNo, objNewCon.ContactName, objNewCon.PhoneNo);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
