﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace lab13d
{
    class SupplierTest
    {
        public static Supplier sup = new Supplier();

        static void Main(string[] args)
        {
            Console.Write("Enter Supplier ID = ");
            sup.SupplierId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Supplier Name = ");
            sup.SupplierName = Console.ReadLine();
            Console.Write("Enter Supplier City = ");
            sup.City = Console.ReadLine();
            Console.Write("Enter Supplier Phone Number = ");
            sup.PhoneNo = Console.ReadLine();
            Console.Write("Enter Supplier Email = ");
            sup.Email = Console.ReadLine();
            sup.AccpetDetail(sup);
            XmlSerialization();
            XmlDeserialization();
            Console.ReadKey();
        }

        static void XmlSerialization()
        {
            FileStream objFS = new FileStream(@"D:\Serialization.xml", FileMode.Create, FileAccess.ReadWrite, FileShare.Read);
            XmlSerializer objXmlS = new XmlSerializer(typeof(Supplier));
            objXmlS.Serialize(objFS, sup);
            objFS.Close();
        }

        static void XmlDeserialization()
        {
            XmlSerializer objXmlS = new XmlSerializer(typeof(Supplier));
            Supplier objSupplier; //creation of object of Supplier class
            using (Stream reader = new FileStream(@"D:\Serialization.xml", FileMode.Open))
            {
                objSupplier = objXmlS.Deserialize(reader) as Supplier;
            }
            Console.WriteLine("\nSupplier Detail:");
            Console.WriteLine("ID = {0}\tName = {1}\tCity = {2}\tphone No = {3}\tEmail = {4}", objSupplier.SupplierId, objSupplier.SupplierName, objSupplier.City, objSupplier.PhoneNo, objSupplier.Email);
        }
    }
}
