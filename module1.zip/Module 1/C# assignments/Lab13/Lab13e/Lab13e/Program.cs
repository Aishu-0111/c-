﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Lab13e
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                List<Supplier> objl = new List<Supplier>();

                for (int i = 0; i < 2; i++)
                {
                    Supplier sp = new Supplier();
                    Console.WriteLine("Enter the id:");
                    sp.id = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the Name:");
                    sp.name = Console.ReadLine();
                    Console.WriteLine("Enter the Capacity:");
                    sp.quantity = Convert.ToInt32(Console.ReadLine());
                    objl.Add(sp);
                }

                using (StreamWriter sw = new StreamWriter("Supplier,txt"))
                {
                    using (JsonWriter writer = new JsonTextWriter(sw))
                    {
                        JsonSerializer serializer = new JsonSerializer();
                        serializer.Serialize(writer, objl);
                        Console.WriteLine("**Serialization Done**");
                    }
                }
 
                using (StreamReader sw = new StreamReader("Supplier,txt"))
                {
                    using (JsonReader reader = new JsonTextReader(sw))
                    {
                        JsonSerializer serializer = new JsonSerializer();
                        List<Supplier> list = serializer.Deserialize<List<Supplier>>(reader);
                        objl = list;
                        Console.WriteLine("**DeSerialization Done**");
                    }
                }

                for (int i = 0; i < objl.Count; i++)
                {
                    Console.WriteLine("Supplier details of:" + (i + 1));
                    Console.WriteLine("Supplier id=" + objl[i].id + "\nSupplier Name=" + objl[i].name + "\nSupplier Capacity=" + objl[i].quantity);
                }
                Console.ReadLine();
            }
        }
    }
}
