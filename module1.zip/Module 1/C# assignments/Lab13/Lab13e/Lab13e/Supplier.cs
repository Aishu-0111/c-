﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13e
{
    class Supplier
    {
        public int id
        {
            get;
            set;
        }

        public string name
        {
            get;
            set;
        }

        public int quantity
        {
            get;
            set;
        }

        public static explicit operator List<object>(Supplier v)
        {
            throw new NotImplementedException();
        }
    }
}
