﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace lab13ab
{
    class Program
    {
        static List<Contact> obj = new List<Contact>();
        static void Main(string[] args)
        {
            int choice;
            char conti;
            do
            {
                Console.WriteLine("** Enter your choice **\n");
                Console.WriteLine("1 To add contact \n2 To display contact \n3 To edit contact \n4 To show all contacts.");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddContact();
                        break;
                    case 2:
                        DisplayContact();
                        break;
                    case 3:
                        EditContact();
                        break;
                    case 4:
                        ShowAllContacts();
                        break;
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Please select a valid option.");
                        break;
                }
                Console.WriteLine("\nDo you want to continue? press 'y' to continue or press 'n' to exit.");
                conti = Convert.ToChar(Console.ReadLine());
            }
            while (conti == 'y');

        }

        static void AddContact()
        {
            Contact contact1 = new Contact();
            Console.WriteLine("Enter Contact No:");
            contact1.ContactNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Contact Name:");
            contact1.ContactName = Console.ReadLine();
            Console.WriteLine("Enter Phone no:");
            contact1.PhoneNo = Console.ReadLine();
            obj.Add(contact1);
            Console.WriteLine("Record Inserted");
            try
            {
                FileStream objFS = new FileStream(@"D:\file io\serialization.dat", FileMode.Append, FileAccess.Write, FileShare.Read);
                BinaryFormatter objBinF = new BinaryFormatter();
                objBinF.Serialize(objFS, contact1);
                objFS.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void DisplayContact()
        {
            int searchCno;
            Console.WriteLine("Enter Contact no you wwant to search:");
            searchCno = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < obj.Count; i++)
            {
                if (obj[i].ContactNo == searchCno)
                {
                    Console.WriteLine("Contact No:{0}\tContact Name:{1}\tCell no:{2}\n", obj[i].ContactNo, obj[i].ContactName, obj[i].PhoneNo);
                }
            }
        }

        static void EditContact()
        {
            int updtCno;
            Console.WriteLine("Enter Contact no you want to update:");
            updtCno = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < obj.Count; i++)
            {
                if (obj[i].ContactNo == updtCno)
                {
                    Console.WriteLine("Update Contact Name:");
                    obj[i].ContactName = Console.ReadLine();
                    Console.WriteLine("Update Cell no :");
                    obj[i].PhoneNo = Console.ReadLine();
                }
                Console.WriteLine("Record Updated");
            }
        }

        static void ShowAllContacts()
        {
            Contact objNewCon;
            try
            {
                FileStream objFS = new FileStream(@"D:\file io\serialization.dat", FileMode.Open, FileAccess.ReadWrite, FileShare.Read);
                BinaryFormatter binary = new BinaryFormatter();
                objNewCon = binary.Deserialize(objFS) as Contact;
                objFS.Close();
                Console.WriteLine("**Binary DeSerialization**");
                Console.WriteLine("\n## Employee Detail ##");
                Console.WriteLine("Contact NO : {0},  Contact NAME: {1},   Cell no: {2}", objNewCon.ContactNo, objNewCon.ContactName, objNewCon.PhoneNo);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
