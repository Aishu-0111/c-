﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firstconsoleapp
{
    class UsingStruct
    {
        static void Main(string[] args)
        {
            Student obj = new Student(101,"Vijay","VII");
            Console.WriteLine("Roll no : {0}\n Name : {1}\n Grade : {2}",obj.rollno,obj.name,obj.grade);
            Console.ReadLine();
        }
    }
}
