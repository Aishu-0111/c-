﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRDS.ENTITY
{
    public class empEntity
    {
        public int Id
        {
            get;
            set;
        }

        public int DesgId
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public int DeptId
        {
            get;
            set;
        }
    }
}
