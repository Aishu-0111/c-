﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRDS.EXCEPTION
{
    public class empException : ApplicationException
    {
       public empException() : base()
        {
        }

       public empException(string msg) : base(msg)
        {                
        }

       public empException(string msg , Exception innerexcepton) : base(msg,innerexcepton)
        {
        }
    }
}
