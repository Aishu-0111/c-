﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using HRDS.ENTITY;
using HRDS.EXCEPTION;

namespace HRDS.DATA_ACCESS
{
    public class empDAL
    {
        public static List<empEntity> empList = new List<empEntity>();

        public bool AddempDAL(empEntity objen)
        {
            bool empadded = false;
            try
            {
                empList.Add(objen);
                empadded = true;
            }
            catch(SystemException ex)
            {
                throw new empException(ex.Message);
            }
            return empadded;
        }

        public bool UpdateempDAL(empEntity objupdate)
        {
            bool empUpdated = false;
            try
            {
                for(int i = 0 ;i < empList.Count; i++)
                {
                    if(empList[i].Id == objupdate.Id)
                    {
                        empList[i].Name = objupdate.Name;
                        empList[i].DesgId = objupdate.DesgId;
                        empList[i].DeptId = objupdate.DeptId;
                        empUpdated = true;
                    }
                }
            }
            catch(SystemException ex)
            {
                throw new empException(ex.Message);
            }
            return empUpdated;
        }

        public bool DelempDAL(int delid)
        {
            bool empDeleted = false;
            try
            {
                empEntity empDel = empList.Find(employee1 => employee1.Id == delid);
                empList.Remove(empDel);
                empDeleted = true;
            }
            catch(SystemException ex)
            {
                throw new empException(ex.Message);
            }
            return empDeleted;
        }

        public empEntity SearchempDAL(int empid)
        {
            empEntity objsearch = null;
            try
            {
                objsearch = empList.Find(emp => emp.Id == empid);
            }
            catch(SystemException ex)
            {
                throw new empException(ex.Message);
            }
            return objsearch;
        }
        
        public List<empEntity> GetemplistDAL()
        {
            return empList;
        }

        public bool Serializedal()
        {
            bool serailzed = false;           
            FileStream objfs = new FileStream(@"D:\Serial\Binaryser.dat", FileMode.Create, FileAccess.Write, FileShare.Read);
            BinaryFormatter objbinf = new BinaryFormatter();
            objbinf.Serialize(objfs, empList);
            objfs.Close();
            serailzed = true;           
            return serailzed;
        }

        public List<empEntity> DeSerializedal()
        {
            FileStream objfs = new FileStream(@"D:\Serial\Binaryser.dat", FileMode.Open, FileAccess.Read, FileShare.Read);
            BinaryFormatter objbinf = new BinaryFormatter();
            List<empEntity> emp = objbinf.Deserialize(objfs) as List<empEntity>;
            return emp;                     
        }
    }
}
