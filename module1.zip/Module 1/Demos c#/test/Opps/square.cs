﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opps
{
    class square:shape
    {
        
        int side;
        public int Side
        {
            get
            {
                return side;
            }
            set
            {                         
                    side = value;            
                
            }
        }
        public square()
        {

        }
        public square(int s)
        {
            this.side = s;
        }
        internal override void calculateArea()
        {
            //base.calculateArea();
            Area = side * side;
        }
        internal override void calculatePeri()
        {
            // base.calculatePeri();
            Peri = 4 * side;
        }
    }
}
