﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opps
{
    class rectangle:shape
    {
        int length, breadth;

        public int Length
        {
            get
            {
                return length;
            }
            set
            {
                length = value;
            }
        }
        public int Breadth
        {
            get
            {
                return breadth;
            }
            set
            {
                breadth = value;
            }
        }
        public rectangle()
        {

        }
        public rectangle(int l , int b)
        {
            this.length = l;
            this.breadth = b;
        }
       
        internal override void calculateArea()
        {
            //base.calculateArea();
            Area = length * breadth;

        }
        internal override void calculatePeri()
        {
            // base.calculatePeri();
            Peri = 2 * (length + breadth);
        }

    }
}
