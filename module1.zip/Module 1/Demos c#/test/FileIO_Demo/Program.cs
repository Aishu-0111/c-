﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileIO_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            //createFileWith_Filestream();
            //writeFileWith_StreamWriter();
            //readFileWith_StreamReader();

            //createFile_UsingFileClass();
            //moveFile_UsingFileClass();  

            //createFile_UsingFileInfoClass();
            //moveFile_UsingFileInfoClass(); 

            //createDirectory_usingDirectoryClass();
            //createDirectory_usingDirectoryInfoClass();

            //GetFile_fromDir();
            Console.ReadKey();

        }

        static void createFileWith_Filestream()
        {

            FileStream file = new FileStream(@"D:\FileIO_Demo\demo.txt", FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.Read);
            file.Close();
        }
        static void readFileWith_StreamReader()
        {
            FileStream objFS = new FileStream(@"D:\FileIO_Demo\demo.txt", FileMode.Open, FileAccess.ReadWrite, FileShare.Read);
            StreamReader objsr = new StreamReader(objFS);
            Console.WriteLine("Reading data from file:");
            string readFromFile = objsr.ReadToEnd();
            //objsr.ReadToEnd();
            objsr.Close();
            objFS.Close();
            Console.WriteLine("{0}",readFromFile);
        }
        static void writeFileWith_StreamWriter()
        {
            FileStream objFS = new FileStream(@"D:\FileIO_Demo\demo.txt", FileMode.Append, FileAccess.Write, FileShare.Read);
            StreamWriter objsw = new StreamWriter(objFS);
            Console.WriteLine("Enter Data in file:");
            objsw.WriteLine(Console.ReadLine());
            objsw.Flush();
            objsw.Close();
            objFS.Close();
        }

        static void createFile_UsingFileClass()
        {
            string strfilePath = @"D:\FileIO_Demo\demo_1.txt";
            if(!File.Exists(strfilePath))
            {
                FileStream objFS = File.Create(strfilePath);
                if(objFS != null)
                {
                    Console.WriteLine("file create successfully");
                }
            }
        }
        static void moveFile_UsingFileClass()
        {
            string strfilePath = @"D:\FileIO_Demo\demo_1.txt";
            string strfileDestination = @"D:\FileIO_Demo\FileIO_newDeastination\demo_1.txt";

            if (File.Exists(strfilePath))
            {
                File.Move(strfilePath, strfileDestination);

                if (File.Exists(strfileDestination))
                {
                    Console.WriteLine("file moves successfully.");
                }
                else
                {
                    Console.WriteLine("file could not moved.");
                }
            }
        }

        static void createFile_UsingFileInfoClass()
        {
            string strfilePath = @"D:\FileIO_Demo\demo_2.txt";
            FileInfo objFI = new FileInfo(strfilePath);
            if (!objFI.Exists)
            {
                FileStream objFS =  objFI.Create();
                if (objFS != null)
                {
                    Console.WriteLine("file create successfully");
                }
                else
                {
                    Console.WriteLine("file could not be created.");
                }
            }
        }
        static void moveFile_UsingFileInfoClass()
        {
            string strfilePath = @"D:\FileIO_Demo\demo_2.txt";
            string strfileDestination = @"D:\FileIO_Demo\FileIO_newDeastination\demo_2.txt";
            FileInfo objFI = new FileInfo(strfilePath);
            if (objFI.Exists)
            {
                objFI.MoveTo(strfileDestination);

                if (File.Exists(strfileDestination))
                {
                    Console.WriteLine("file moves successfully.");
                }
                else
                {
                    Console.WriteLine("file could not moved.");
                }
            }
        }

        static void createDirectory_usingDirectoryClass()
        {
            string strDirectory = @"D:\FileIO_Demo\New_Directory";
            if(!Directory.Exists(strDirectory))
            {
                Directory.CreateDirectory(strDirectory);
                if (Directory.Exists(strDirectory))
                {
                    Console.WriteLine("Directory created successfully");

                }
                else
                {
                    Console.WriteLine("Directory not created.");
                }
            }
        }
        static void createDirectory_usingDirectoryInfoClass()
        {
            string strDirectory = @"D:\FileIO_Demo\New_Directory2";
            DirectoryInfo objDI = new DirectoryInfo(strDirectory);
            if (!objDI.Exists)
            {
                objDI.Create();
                if (!objDI.Exists)
                {
                    Console.WriteLine("Directory created successfully");

                }
                else
                {
                    Console.WriteLine("Directory not created.");
                }
            }
        }

        static void GetFile_fromDir()
        {
            string strDirPath = @"D:\FileIO_Demo";
            if(Directory.Exists(strDirPath))
            {
                string[] strFiles = Directory.GetFiles(strDirPath);
                Console.WriteLine("--------List of Files------------");
                foreach(string strfile in strFiles)
                {
                    
                    string strFilename = Path.GetFileName(strfile);
                    Console.WriteLine(" File Name with Extension : "+strFilename);
                    string strFilenameWithoutExe = Path.GetFileNameWithoutExtension(strfile);
                    Console.WriteLine(" File Name with Extension : " + strFilenameWithoutExe);
                }
                string[] strDirs = Directory.GetDirectories(strDirPath);
                Console.WriteLine("--------List of Directories------------");
                foreach (string strDir in strDirs)
                {
                    string strDirname = Path.GetFileName(strDir);
                    Console.WriteLine(strDirname);
                }


            }

        }
    }
}
