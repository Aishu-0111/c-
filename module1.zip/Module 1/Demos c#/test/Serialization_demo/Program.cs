﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Xml.Serialization;


namespace Serialization_demo
{
    /**serialization:
         * Serialization is the processs of writing the state of an object to a byte stream.
         * write the stream :
         *      -xml File
         *      -soap file
         *      -Binary file
         * Deserialization   
        **/
    class Program
    {
        static Employee objEmp = new Employee();
        static void Main(string[] args)
        {
            fillEmployee();

            //binarySerialization();
            binaryDeserialization();

            //SoapSerialization();
            SoapDeserialization();

            //XmlSerialization();
            XmlDeserialization();

            Console.ReadKey();

        }
        static void binarySerialization()
        {
            FileStream objFS = new FileStream(@"D:\Serialization_demo\BinarySer.dat", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
            BinaryFormatter objBinF = new BinaryFormatter();
            objBinF.Serialize(objFS, objEmp);
            objFS.Close();
        }
        static void binaryDeserialization()
        {
            FileStream objFS = new FileStream(@"D:\Serialization_demo\BinarySer.dat", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
            BinaryFormatter objBinF = new BinaryFormatter();
            Employee objNewEmp  = objBinF.Deserialize(objFS) as Employee;
            objFS.Close();
            Console.WriteLine("-----------------Binary Serialization--------------");
            Console.WriteLine("-- Employee Detail--");
            Console.WriteLine("ID : {0},NAME:{1},DesignationID:{2},DepartmentID:{3},AGE:{4}",objEmp.EmpID,objEmp.EmpName,objEmp.DesignationID,objEmp.DepartmentID, objEmp.Age);
        }

        static void SoapSerialization()
        {
            FileStream objFS = new FileStream(@"D:\Serialization_demo\SoapSer.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
            SoapFormatter objSoapF = new SoapFormatter();
            objSoapF.Serialize(objFS, objEmp);
            objFS.Close();
        }
        static void SoapDeserialization()
        {
            FileStream objFS = new FileStream(@"D:\Serialization_demo\SoapSer.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
            SoapFormatter objSoapF = new SoapFormatter();
            Employee objNewEmp = objSoapF.Deserialize(objFS) as Employee;
            objFS.Close();
            Console.WriteLine("-----------------SOAP Serialization--------------");
            Console.WriteLine("-- Employee Detail--");
            Console.WriteLine("ID : {0},NAME:{1},DesignationID:{2},DepartmentID:{3},AGE : {4}", objEmp.EmpID, objEmp.EmpName, objEmp.DesignationID, objEmp.DepartmentID, objEmp.Age);
        }

        static void XmlSerialization()
        {
            FileStream objFS = new FileStream(@"D:\Serialization_demo\XmlSer.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
            XmlSerializer objXmlS = new XmlSerializer(typeof(Employee));
            objXmlS.Serialize(objFS, objEmp);
            objFS.Close();
        }
        static void XmlDeserialization()
        {
            FileStream objFS = new FileStream(@"D:\Serialization_demo\XmlSer.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
            XmlSerializer objXmlS = new XmlSerializer(typeof(Employee));
            Employee objNewEmp = objXmlS.Deserialize(objFS) as Employee;
            objFS.Close();
            Console.WriteLine("-----------------Xml Serialization--------------");
            Console.WriteLine("-- Employee Detail--");
            Console.WriteLine("ID : {0},NAME:{1},DesignationID:{2},DepartmentID:{3} , AGE: {4}", objEmp.EmpID, objEmp.EmpName, objEmp.DesignationID, objEmp.DepartmentID, objEmp.Age);
        }

        static void fillEmployee()
        {
            int id = 1, DesgID = 1, DepartID = 1;
            string name = "Amanda";
            objEmp.EmpID = id;
            objEmp.EmpName = name;
            objEmp.DepartmentID = DepartID;
            objEmp.DesignationID = DesgID;
            objEmp.DOB = 1998;
            objEmp.onDeserial();
        }
    }
}
