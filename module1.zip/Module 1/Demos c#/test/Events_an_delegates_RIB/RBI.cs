﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events_an_delegates_RIB
{
    delegate void AccountHandeler();
    internal class RBI
    {
        int _balance;
        internal event AccountHandeler underBalance;
        internal event AccountHandeler overBalance;

        internal RBI(int balance) {
            _balance = balance;
        }

        internal void Withdraw(int amount)
        {
            _balance = _balance - amount;
            if (_balance < 500)
            {
                //penelty
                underBalance();
            }
        }
        internal void Deposit(int amount)
        {
            _balance = _balance + amount;
            if (_balance > 1000000)
            {
                //tax
                overBalance();
            }
        }
    }
}
