﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstractclss
{
    abstract class shape
    {
         int area;
         int peri;

        public int Area
        {
            get {
                return area;
            }
            set {
                area = value;
            }
        }

        public int Peri
        {
            get
            {
                return peri;
            }
            set
            {
                peri = value;
            }
        }

        public shape() { }

        internal abstract void calculateArea();
        
        internal abstract void calculatePeri();

    }
}
