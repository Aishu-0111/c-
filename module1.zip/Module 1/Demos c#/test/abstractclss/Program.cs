﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstractclss
{
    class Program
    {
        static void Main(string[] args)
        {
            int l, b;
            l = 5;
            b = 10;
            rectangle obj1 = new rectangle(l, b);
            obj1.calculateArea();
            Console.WriteLine("Area of Rectangle = " + obj1.Area);
            obj1.calculatePeri();
            Console.WriteLine("Perimeter of Rectangle = " + obj1.Peri);
            Console.ReadKey();
            //shape obj = new shape();  abstract class cannot have an object. Throws Error 
        }
    }
}
