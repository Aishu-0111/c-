﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oop_demo2
{
    abstract class Shape
    {
        int area;
        int perimeter;

    public int Area
    {
        get
        {
            return area;
        }
        set
        {
            area = value;
        }
    }

    public int Perimeter
    {
        get
        {
            return perimeter;
        }
        set
        {
            perimeter = value;
        }
    }

    public Shape()
    {

    }

    internal abstract void ARea();

    internal abstract void PErimeter();

    }
}
