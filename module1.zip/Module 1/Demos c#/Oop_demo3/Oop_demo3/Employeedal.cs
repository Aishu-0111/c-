﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Oop_demo3
{
    class Employeedal
    {
        void CreateEmployee()
        {
            SqlConnection objcon = new SqlConnection(Database.ConnectionString);
            SqlCommand objcom = new SqlCommand("Create employee......",objcon);
        }

        void DeleteEmployee()
        {
            SqlConnection objcon = new SqlConnection("server = .; database = employeemgmt; integrated security = true");
            SqlCommand objcom = new SqlCommand("Delete employee......", objcon);
        }

        void UpdateEmployee()
        {
            SqlConnection objcon = new SqlConnection("server = .; database = employeemgmt; integrated security = true");
            SqlCommand objcom = new SqlCommand("Update employee......", objcon);
        }

        void SearchEmployee()
        {
            SqlConnection objcon = new SqlConnection("server = .; database = employeemgmt; integrated security = true");
            SqlCommand objcom = new SqlCommand("Search employee......", objcon);
        }

        void ListEmployee()
        {
            SqlConnection objcon = new SqlConnection("server = .; database = employeemgmt; integrated security = true");
            SqlCommand objcom = new SqlCommand("List employee......", objcon);
        }
    }
}
