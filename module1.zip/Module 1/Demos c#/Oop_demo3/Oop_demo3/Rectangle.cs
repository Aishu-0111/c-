﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oop_demo3
{
    class Rectangle : Ishape
    {
        int length;
        int breadth;

        public int Length
        {
            get
            {
                return length;
            }
            set
            {
                length = value;
            }
        }

        public int Breadth
        {
            get
            {
                return breadth;
            }
            set
            {
                breadth = value;
            }
        }

        public int Area
        {
            get;
            set;
        }

        public int Perimeter
        {
            get;
            set;
        }

        public Rectangle()
        {

        }

        public Rectangle(int length, int breadth)
        {
            this.length = length;
            this.breadth = breadth;
        }

        public void ARea()
        {
            // base.Area();
            Area = length * breadth;
        }

        public void PErimeter()
        {
            // base.Perimeter();
            Perimeter = 2 * (length + breadth);
        }
    }
}

