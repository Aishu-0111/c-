﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops_demo1
{
    class square : Shape
    {
        int sides;

        public int Side
        {
            get
            {
                return sides;
            }
            set
            {
                sides = value;
            }
        }

        public square()
        {

        }

        public square(int sides)
        {
            this.sides = sides;
        }

        internal new void Display()
        {

        }

        internal override void ARea()
        {
            // base.Area();
            Area = sides * sides;
        }

        internal override void PErimeter()
        {
            // base.Perimeter();
            Perimeter = 2 ;
        }
    }
}
