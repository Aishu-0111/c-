﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops_demo1
{
    class Rectangle : Shape
    {
        int length;
        int breadth;

        public int Length
        {
            get
            {
                return length;
            }
            set
            {
                length = value;
            }
        }

        public int Breadth
        {
            get
            {
                return breadth;
            }
            set
            {
                breadth = value;
            }
        }

        public Rectangle()
        {

        }

        public Rectangle(int length, int breadth)
        {
            this.length = length;
            this.breadth = breadth;
        }

        public void getData(int length, int breadth)
        {

        }

        internal new void Display()
        {

        }

        internal override void ARea()
        {
            // base.Area();
            Area = length * breadth;
        }

        internal override void PErimeter()
        {
            // base.Perimeter();
            Perimeter = 2 * (length + breadth);
        }
    }
}
