﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS.BusinessLayer;
using HRDS.Entities;
using HRDS.Exceptions;

namespace HRDS.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {

            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddEmployee();
                        break;
                    case 2:
                        ListAllEmployees();
                        break;
                    case 3:
                        SearchEmployee();
                        break;
                    case 4:
                        UpdateEmployee();
                        break;
                    case 5:
                        DeleteEmployee();
                        break;
                    case 6:
                        SerializeEmployee();
                        break;
                    case 7:
                        DeSerializeEmployee();
                        break;
                    case 8:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }

        static void AddEmployee()
        {
            try
            {
                Employee employee = new Employee();
                Console.WriteLine("Enter ID.");
                employee.Id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Name.");
                employee.Name = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter Designation ID.");
                employee.DesignationId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Department ID.");
                employee.DepartmentId = Convert.ToInt32(Console.ReadLine());
                bool employeeAdded = EmployeeBL.AddEmployeeBL(employee);
                if(employeeAdded)
                {
                    Console.WriteLine("Employee Added Successfully..");
                }
                else
                {
                    Console.WriteLine("Employee couldn't be Added..");
                }
            }
            catch (HRDSException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
        static void UpdateEmployee()
        {
            try
            {
                int updateEmployeeId ;
                Console.WriteLine("Enter Employee ID to Update Details:");
                updateEmployeeId = Convert.ToInt32(Console.ReadLine());
                Employee updatedEmployee = EmployeeBL.SearchEmployeeBL(updateEmployeeId);
                if (updatedEmployee != null)
                {
                    Console.WriteLine("Update Employee Name :");
                    updatedEmployee.Name = Console.ReadLine();
                    Console.WriteLine("Update Employee Designation Id:");
                    updatedEmployee.DesignationId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Update Employee Department Id:");
                    updatedEmployee.DepartmentId = Convert.ToInt32(Console.ReadLine());
                    bool employeeUpdated = EmployeeBL.UpdateEmployeeBL(updatedEmployee);
                    if (employeeUpdated)
                        Console.WriteLine("Employee Details Updated");
                    else
                        Console.WriteLine("Employee Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }


            }
            catch (HRDSException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void SearchEmployee()
        {
            try
            {
                int searchEmployeeId;
                Console.WriteLine("Enter Employee ID to Search:");
                searchEmployeeId = Convert.ToInt32(Console.ReadLine());
                Employee searchEmployee = EmployeeBL.SearchEmployeeBL(searchEmployeeId);
                if (searchEmployee != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("EmployeeId\tName\tDesignationId\tDepartmentId");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}", searchEmployee.Id, searchEmployee.Name, searchEmployee.DesignationId, searchEmployee.DepartmentId);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }

            }
            catch (HRDSException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void DeleteEmployee()
        {
            try
            {
                int deleteEmployeeID;
                Console.WriteLine("Enter Employee Id to Delete:");
                deleteEmployeeID = Convert.ToInt32(Console.ReadLine());
                Employee deleteEmployee = EmployeeBL.SearchEmployeeBL(deleteEmployeeID);
                if (deleteEmployee != null)
                {
                    bool employeedeleted = EmployeeBL.DeleteEmployeeBL(deleteEmployeeID);
                    if (employeedeleted)
                        Console.WriteLine("Employee Deleted");
                    else
                        Console.WriteLine("Employee not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }


            }
            catch (HRDSException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void ListAllEmployees()
        {
            try
            {
                List<Employee> employeeList = EmployeeBL.GetAllEmployeeBL();
                if (employeeList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("EmployeeId\t\tName\t\tDesignationId\t\tDepartmentId");
                    Console.WriteLine("******************************************************************************");
                    foreach (Employee employee in employeeList)
                    {
                        Console.WriteLine("{0}\t\t\t{1}\t\t\t{2}\t\t\t{3}", employee.Id, employee.Name, employee.DesignationId, employee.DepartmentId);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (HRDSException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeEmployee()
        {
           
            EmployeeBL.SerializeEmployeeBL();
            Console.WriteLine("Serialization Done.");
        }
        public static void DeSerializeEmployee()
        {
            Console.WriteLine("---DeSerialization---");
            List<Employee> EmployeeList = new List<Employee>();
            EmployeeList = EmployeeBL.DeSerializeEmployeeBL();
            PrintDetails(EmployeeList);
        }
        public static void PrintDetails(List<Employee> EmployeeList)
        {
            for(int i=0; i < EmployeeList.Count; i++)
            {
                Console.WriteLine("\n--Employee Details--");
                Console.WriteLine("Employee Id: {0},\nEmployee Name: {1},\nDesignation Id: {2},\nDepartment Id: {3}", EmployeeList[i].Id, EmployeeList[i].Name, EmployeeList[i].DesignationId, EmployeeList[i].DepartmentId);
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n***********HRDS Application Menu***********");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. List All Employee");
            Console.WriteLine("3. Search Employee by ID");
            Console.WriteLine("4. Update Employee");
            Console.WriteLine("5. Delete Employee");
            Console.WriteLine("6. Serialize Employee");
            Console.WriteLine("7. DeSerialize Employee");
            Console.WriteLine("8. Exit");
            Console.WriteLine("******************************************\n");

        }
    }
}
