﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCollection
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Non generic list
            DemoArrayList();
            Demostack();
            DemoQueue();
            DemoHashtable();
            */
            /* Generic list
           DemoGenericlist();
           DemoGenericStack();
           DemoGenericQueue();
           DemoGenericDictionary();
           */
        }

        static void DemoArrayList()
        {
            ArrayList objarr = new ArrayList();
            objarr.Add("India");
            objarr.Add("Sri Lanka");
            objarr.Add("China");

            Console.WriteLine("\nThe capacity of collection is : " +objarr.Capacity);
            Console.WriteLine("The count of collection is : " + objarr.Count);

            Console.WriteLine("\n**List of countries using for loop**\n");
            for(int i = 0; i < objarr.Count; i ++)
            {
                Console.WriteLine(objarr[i]);
            }

            Console.WriteLine("\n**List of countries using for each loop**\n");
            foreach (var obj in objarr)
            {
                Console.WriteLine(obj);
            }

            object[] objC = new object[objarr.Count];
            objarr.CopyTo(objC);
            Console.WriteLine("\n**List of countries after copying**\n");
            foreach(var objCoun in objC)
            {
                Console.WriteLine(objCoun);
            }

            bool contains = objarr.Contains("India");
            Console.WriteLine("\nIndia is in the list : " + contains);

            objarr.Insert(2, "America");
            Console.WriteLine("\n**List of countries after adding**\n");
            foreach(var objadd in objarr)
            {
                Console.WriteLine(objadd);
            }

            objarr.Remove("China");
            Console.WriteLine("\n**List of countries after removing**\n");
            foreach (var objrem in objarr)
            {
                Console.WriteLine(objrem);
            }

            objarr.Sort();
            Console.WriteLine("\n**List of countries after sorting**\n");
            foreach(var sort in objarr)
            {
                Console.WriteLine(sort);
            }
            Console.ReadLine();
        }

        static void Demostack()
        {
            Stack objSt = new Stack();
            objSt.Push("jan");
            objSt.Push("Feb");
            objSt.Push("March");
            objSt.Push("April");

            Console.WriteLine("\n**List of months using for each loop**\n");
            foreach (var objM in objSt)
            {
                Console.WriteLine(objM);
            }

            Console.WriteLine("\nItem poped : " +objSt.Pop());
            Console.WriteLine("\n**List of months after calling pop method**\n");
            foreach (var objPop in objSt)
            {
                Console.WriteLine(objPop);
            }

            Console.WriteLine("\nItem peek : " + objSt.Peek());
            Console.WriteLine("\n**List of months after calling peek method**\n");
            foreach (var objPk in objSt)
            {
                Console.WriteLine(objPk);
            }
            Console.ReadLine();
        }

        static void DemoQueue()
        {
            Queue objQ = new Queue();
            objQ.Enqueue("Mon");
            objQ.Enqueue("Tues");
            objQ.Enqueue("Wed");
            objQ.Enqueue("Thurs");

            Console.WriteLine("\n**List of days using for each loop**\n");
            foreach (var objW in objQ)
            {
                Console.WriteLine(objW);
            }

            Console.WriteLine("\nItem dequeued : " + objQ.Dequeue());
            Console.WriteLine("\n**List of days after calling Dequeue method**\n");
            foreach (var objdq in objQ)
            {
                Console.WriteLine(objdq);
            }

            Console.WriteLine("\nItem peek : " + objQ.Peek());
            Console.WriteLine("\n**List of days after calling peek method**\n");
            foreach (var objPkq in objQ)
            {
                Console.WriteLine(objPkq);
            }
            Console.ReadLine();
        }

        static void DemoHashtable()
        {
            Hashtable objH = new Hashtable();
            objH.Add(101,"Aishu");
            objH.Add(102,"Suji");
            objH.Add(103,"Meghna");
            objH.Add(104,"Siva");

            Console.WriteLine("\n**List of employees using foreach loop**\n");
            foreach(DictionaryEntry objE in objH)
            {
                Console.WriteLine("Key : " +objE.Key+ ", Value : " +objE.Value);
            }

            Console.WriteLine("\n**List of employees using while loop**\n");
            IDictionaryEnumerator objDe = objH.GetEnumerator();
            while(objDe.MoveNext())
            {
                Console.WriteLine("Key : " + objDe.Key + ", Value : " + objDe.Value);
            }
            Console.ReadLine();
        }

        static void DemoGenericlist()
        {
            List<string> objarr = new List<string>();
            objarr.Add("India");
            objarr.Add("Sri Lanka");
            objarr.Add("China");

            Console.WriteLine("\nThe capacity of collection is : " + objarr.Capacity);
            Console.WriteLine("The count of collection is : " + objarr.Count);

            Console.WriteLine("\n**List of countries using for loop**\n");
            for (int i = 0; i < objarr.Count; i++)
            {
                Console.WriteLine(objarr[i]);
            }

            Console.WriteLine("\n**List of countries using for each loop**\n");
            foreach (var obj in objarr)
            {
                Console.WriteLine(obj);
            }

            bool contains = objarr.Contains("India");
            Console.WriteLine("\nIndia is in the list : " + contains);

            objarr.Insert(2, "America");
            Console.WriteLine("\n**List of countries after adding**\n");
            foreach (var objadd in objarr)
            {
                Console.WriteLine(objadd);
            }

            objarr.Remove("China");
            Console.WriteLine("\n**List of countries after removing**\n");
            foreach (var objrem in objarr)
            {
                Console.WriteLine(objrem);
            }

            objarr.Sort();
            Console.WriteLine("\n**List of countries after sorting**\n");
            foreach (var sort in objarr)
            {
                Console.WriteLine(sort);
            }
            Console.ReadLine();
        }

        static void DemoGenericStack()
        {
            Stack <string> objSt = new Stack<string>();
            objSt.Push("jan");
            objSt.Push("Feb");
            objSt.Push("March");
            objSt.Push("April");

            Console.WriteLine("\n**List of months using for each loop**\n");
            foreach (var objM in objSt)
            {
                Console.WriteLine(objM);
            }

            Console.WriteLine("\nItem poped : " + objSt.Pop());
            Console.WriteLine("\n**List of months after calling pop method**\n");
            foreach (var objPop in objSt)
            {
                Console.WriteLine(objPop);
            }

            Console.WriteLine("\nItem peek : " + objSt.Peek());
            Console.WriteLine("\n**List of months after calling peek method**\n");
            foreach (var objPk in objSt)
            {
                Console.WriteLine(objPk);
            }
            Console.ReadLine();
        }

        static void DemoGenericQueue()
        {
            Queue <string> objQ = new Queue <string>();
            objQ.Enqueue("Mon");
            objQ.Enqueue("Tues");
            objQ.Enqueue("Wed");
            objQ.Enqueue("Thurs");

            Console.WriteLine("\n**List of days using for each loop**\n");
            foreach (var objW in objQ)
            {
                Console.WriteLine(objW);
            }

            Console.WriteLine("\nItem dequeued : " + objQ.Dequeue());
            Console.WriteLine("\n**List of days after calling Dequeue method**\n");
            foreach (var objdq in objQ)
            {
                Console.WriteLine(objdq);
            }

            Console.WriteLine("\nItem peek : " + objQ.Peek());
            Console.WriteLine("\n**List of days after calling peek method**\n");
            foreach (var objPkq in objQ)
            {
                Console.WriteLine(objPkq);
            }
            Console.ReadLine();
        }

        static void DemoGenericDictionary()
        {
            Dictionary <int,string> objH = new Dictionary<int,string>();
            objH.Add(101, "Aishu");
            objH.Add(102, "Suji");
            objH.Add(103, "Meghna");
            objH.Add(104, "Siva");

            Console.WriteLine("\n**List of employees using foreach loop**\n");
            foreach (KeyValuePair<int,string> objE in objH)
            {
                Console.WriteLine("Key : " + objE.Key + ", Value : " + objE.Value);
            }

            Console.WriteLine("\n**List of employees using while loop**\n");
            IDictionaryEnumerator objDe = objH.GetEnumerator();
            while (objDe.MoveNext())
            {
                Console.WriteLine("Key : " + objDe.Key + ", Value : " + objDe.Value);
            }
            Console.ReadLine();
        }

    }
}
