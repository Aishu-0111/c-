﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMPL_DAL;
using PMPL_EXCEPTIONHANDLING;
using PMPL_ENTITY;
using System.Text.RegularExpressions;

namespace PMPL_BL
{
    public class PMPLBl
    {
        //Validating data entered by the Service Engineer
        private static bool Validate(PMPLEn objentity)
        {
            StringBuilder sb = new StringBuilder();
            bool validateroute = true;

            if (objentity.RouteID <= 10 || objentity.RouteID > 1000)
            {
                validateroute = false;
                sb.Append("\nRouteId should be 2 to 3 digits long (for ex.41,123).");
            }

            if (objentity.BusType.ToUpper() != "AC" && objentity.BusType.ToUpper() != "NON-AC")
            {
                validateroute = false;
                sb.Append("\nBus Type should be 'AC' or 'Non-AC'.");
            }

            if (!Regex.Match(objentity.Capacity.ToString(), "^[0-9]*$").Success)
            {
                validateroute = false;
                sb.Append("\nCapacity should be only in digits'.");
            }

            if (!Regex.Match(objentity.Fare.ToString(), "^[0-9]*$").Success)
            {
                validateroute = false;
                sb.Append("\nFare should be only in digits.");
            }

            if (!Regex.Match(objentity.BusNo.ToUpper(), "^[A-Z][A-Z]-[0-9][0-9]-[A-Z][A-Z]-[0-9][0-9][0-9][0-9]$").Success)
            {
                validateroute = false;
                sb.Append("\nBus Number should have first 2 alphabets, hyphen, 2 digit, hyphen, 2 alphabets, hyphen then 4 digi (for ex : MH-01-AB-1000).");
            }

            if (!Regex.Match(objentity.RouteFrom, "^[a-zA-Z]*$").Success)
            {
                validateroute = false;
                sb.Append("\nRoute From : accepts only Alphabets ");
            }

            if (!Regex.Match(objentity.RouteTo, "^[a-zA-Z]*$").Success)
            {
                validateroute = false;
                sb.Append("\nRoute To : accept only Alphabets");
            }

            if (objentity.Fare.ToString() == string.Empty || objentity.RouteID.ToString() == string.Empty || objentity.Capacity.ToString() == string.Empty)
            {
                validateroute = false;
                sb.Append("\nRouteid, Fare, Capacity field cannot be left Empty plese enter a Valid Value.");
            }

            if (objentity.BusNo == string.Empty || objentity.BusType == string.Empty || objentity.RouteFrom == string.Empty || objentity.RouteTo == string.Empty)
            {
                validateroute = false;
                sb.Append("\nRoute From , Route To , Bus Number , Bus Type field cannot be Empty .... \nPlease enter a Valid Value.");
            }
            
            if (validateroute == false)
            {
                throw new PMPLException(sb.ToString());
            }
            return validateroute; 
        }

        //Providing data to the data access layer
        public static bool AddrouteBL(PMPLEn addroute)
        {
            bool routeadded = false;
            try
            {
                if (Validate(addroute))
                {
                    PMPLDal objadd = new PMPLDal();
                    objadd.AddRouteDAL(addroute);
                    routeadded = true;
                }
            }
            catch (PMPLException ex)
            {
                throw ex;
            }
            return routeadded;
        }

        //Updating data in the data access layer
        public static bool UpdaterouteBL(PMPLEn updateroute)
        {
            bool routeupdated = false;
            try
            {
                if (Validate(updateroute))
                {
                    PMPLDal objadd = new PMPLDal();
                    objadd.UpdateRouteDAL(updateroute);
                    routeupdated = true;
                }
            }
            catch (PMPLException ex)
            {
                throw ex;
            }
            return routeupdated;
        }

        //Deleting data from the data access layer
        public static bool DeleterouteBL(int delrouteId)
        {
            bool routedeleted = false;
            try
            {
                if (delrouteId > 0)
                {
                    PMPLDal objadd = new PMPLDal();
                    objadd.DeleteRouteDAL(delrouteId);
                    routedeleted = true;
                }               
            }
            catch (PMPLException ex)
            {
                throw ex;
            }
            return routedeleted;
        }

        //Searching data from the data access layer
        public static PMPLEn SearchrouteBL(int searchid)
        {
            PMPLEn objsearch = null;
            try
            {
                if (searchid > 0)
                {
                    PMPLDal objadd = new PMPLDal();
                    objsearch = objadd.SearchRouteDAL(searchid);                   
                }
            }
            catch (PMPLException ex)
            {
                throw ex;
            }
            return objsearch;
        }

        //Calling serialization function from data access layer
        public static void SerializeRouteBL()
        {
            PMPLDal objserilaize = new PMPLDal();
           objserilaize.SerializeRouteDAL();
        }

        //Calling De-serialization function from data access layer
        public static List<PMPLEn> DeSerializeBL()
        {
            List<PMPLEn> buslist = new List<PMPLEn>();
            PMPLDal objdeserialize = new PMPLDal();
            buslist = objdeserialize.DeSerializeDAL();
            return buslist;
        }
    }
}
