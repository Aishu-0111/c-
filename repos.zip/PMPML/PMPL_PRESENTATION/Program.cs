﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMPL_BL;
using PMPL_DAL;
using PMPL_EXCEPTIONHANDLING;
using PMPL_ENTITY;

namespace PMPL_PRESENTATION
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            char select;
            do
            {
                PrintMenu();
                Console.WriteLine("\nPlease enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1 :
                        Addroute();
                        break;
                    case 2 :
                        Searchroute();
                        break;
                    case 3 :
                        Updateroute();
                        break;
                    case 4 :
                        Deleteroute();
                        break;
                    case 5 :
                        Serialization();
                        break;
                    case 6 :
                        DeSerialization();
                        break;
                    case 7 :
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\nPlease enter valid option...");
                        break;
                }
                Console.WriteLine("\nDo you want to continue ?? \nPress 'y' for more");
                select = Convert.ToChar(Console.ReadLine());
            } while (select == 'y');
        }

        //Providing User Interface for Adding data
        static void Addroute()
        {
            try
            {
                PMPLEn objadd = new PMPLEn();
                Console.WriteLine("Enter Route Id : ");
                objadd.RouteID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Route From : ");
                objadd.RouteFrom = Console.ReadLine();
                Console.WriteLine("Enter Route To : ");
                objadd.RouteTo = Console.ReadLine();
                Console.WriteLine("Enter Bus no : ");
                objadd.BusNo = Console.ReadLine();
                Console.WriteLine("Enter Bus Type : ");
                objadd.BusType = Console.ReadLine();
                Console.WriteLine("Enter Bus Capacity : ");
                objadd.Capacity = Console.ReadLine();
                Console.WriteLine("Enter Bus Fare : ");
                objadd.Fare = Console.ReadLine();
                bool routeadded = PMPLBl.AddrouteBL(objadd);
                if (routeadded)
                {
                    Console.WriteLine("Route added successfully");
                }
                else
                {
                    Console.WriteLine("Route couldn't be added");
                }
            }
            catch(PMPLException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Providing User Interface for Searching data
        static void Searchroute()
        {
            try
            {
                int searchid;
                Console.WriteLine("Enter the ID you want to search : ");
                searchid = Convert.ToInt32(Console.ReadLine());
                PMPLEn objentity = PMPLBl.SearchrouteBL(searchid);
                if (objentity != null)
                {
                    Console.WriteLine("**Info you requested**\n");
                    Console.WriteLine("\nRoute Id Route From Route To  Bus Type Capacity Fare Bus No\n");
                    Console.WriteLine("{0}   \t{1}\t{2}\t{3} \t{4}\t{5}\t{6}",objentity.RouteID,objentity.RouteFrom,objentity.RouteID,objentity.BusType,objentity.Capacity,objentity.Fare, objentity.BusNo);
                }
                else
                {
                    Console.WriteLine("Enter Valid Id");
                }
            }
            catch (PMPLException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Providing User Interface for Updating data
        static void Updateroute()
        {
            try
            {
                int updateid;
                Console.WriteLine("Enter the ID you want to update : ");
                updateid = Convert.ToInt32(Console.ReadLine());
                PMPLEn objentity = PMPLBl.SearchrouteBL(updateid);
                if (objentity != null)
                {
                    PMPLEn objadd = new PMPLEn();
                    Console.WriteLine("Enter Route From : ");
                    objadd.RouteFrom = Console.ReadLine();
                    Console.WriteLine("Enter Route To : ");
                    objadd.RouteTo = Console.ReadLine();
                    Console.WriteLine("Enter Bus no : ");
                    objadd.BusNo = Console.ReadLine();
                    Console.WriteLine("Enter Bus Type : ");
                    objadd.BusType = Console.ReadLine();
                    Console.WriteLine("Enter Bus Capacity : ");
                    objadd.Capacity = Console.ReadLine();
                    Console.WriteLine("Enter Bus Fare : ");
                    objadd.Fare =Console.ReadLine();
                    bool routeupdated = PMPLBl.UpdaterouteBL(objadd);
                    if (routeupdated)
                    {
                        Console.WriteLine("Route Updated !!");
                    }
                    else
                    {
                        Console.WriteLine("Route could not be updated ");
                    }
                }
                else
                {
                    Console.WriteLine("\nEnter valid ID !!");
                }
            }
            catch (PMPLException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Providing User Interface for Deleting data
        static void Deleteroute()
        {
            try
            {
                int deleteid;
                Console.WriteLine("Enter the ID you want to delete : ");
                deleteid = Convert.ToInt32(Console.ReadLine());
                PMPLEn objentity = PMPLBl.SearchrouteBL(deleteid);
                if(objentity != null)
                {
                    bool routedeleted = PMPLBl.DeleterouteBL(deleteid);
                    if (routedeleted)
                    {
                        Console.WriteLine("Successfully Deleted !!!");
                    }
                    else
                    {
                        Console.WriteLine("Route could not be deleted");
                    }
                }
                else
                {
                    Console.WriteLine("Enter valid Id !!!");
                }
            }
            catch(PMPLException ex)
            {
                Console.WriteLine(ex.Message);
            }           
        }

        //Providing User Interface for performing serialization
        public static void Serialization()
        {
            PMPLBl.SerializeRouteBL();
            Console.WriteLine("Serialization done successfully !!!");
        }

        //Providing User Interface for performing de-serialization
        public static void DeSerialization()
        {
            Console.WriteLine("\n****De-Serialization****\n");
            List<PMPLEn> buslist = new List<PMPLEn>();
            buslist = PMPLBl.DeSerializeBL();
            foreach(PMPLEn bus in buslist)
            {
                Console.WriteLine("Route Id : {0} \nRoute From : {1} \nRoute To : {2} \nBusNo : {3} \nBus Type : {4} \nCapacity : {5} \nFare : {6}", bus.RouteID, bus.RouteFrom, bus.RouteTo, bus.BusNo, bus.BusType, bus.Capacity,bus.Fare);
            }
        }

        //For allowing user to select any action
        static void PrintMenu()
        {
            Console.WriteLine("**Bus Info**\n");
            Console.WriteLine("Press 1 for Adding Route.");
            Console.WriteLine("Press 2 for Searching any Route.");
            Console.WriteLine("Press 3 for Updating Route.");
            Console.WriteLine("Press 4 for Deleting Route.");
            Console.WriteLine("Press 5 for Performing Serialization.");
            Console.WriteLine("Press 6 for Performing De-Serialization.");
            Console.WriteLine("Press 7 for Exit");
        }
    }
}
