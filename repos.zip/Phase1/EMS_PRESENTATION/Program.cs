﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_PRESENTATION
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            char option;
            do
            {
                Printmenu();
                Console.WriteLine("\nEnter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1 :
                        Add();
                        break;
                    case 2 :
                        Update();
                        break;
                    case 3 :
                        Delete();
                        break; 
                    case 4 :
                        Search();
                        break;
                    case 5 :
                        View();
                        break;
                    case 6 :
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("\nPress 'y' to continue..");
                option = Convert.ToChar(Console.ReadLine());
            } while (option == 'y');
        }

        private static void Printmenu()
        {

        }

        private static void Add()
        {

        }

        private static void Update()
        {

        }

        private static void Delete()
        {

        }

        private static void Search()
        {

        }

        private static void View()
        {

        }
        
    }
}
