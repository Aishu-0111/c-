﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_entity
{
    public class EmployeeEnity
    {
        int Empid, KinId, DeptId, ProjectId, RoleId;
        string EmpName, EmpAdd, emailId, DeptName, RoleName, DeptDescription, ProjName, ProjDescription, RoleDescription, PhoneNo;
        DateTime Dob, DateofJoining;

        public int EMPid
        {
            get
            {
                return Empid;

            }
            set
            {
                Empid = value;
            }
        }

        public int KINid
        {
            get
            {
                return KinId;

            }
            set
            {
                KinId = value;
            }
        }

        public int DEPTid
        {
            get
            {
                return DeptId;

            }
            set
            {
               DeptId = value;
            }
        }

        public int PROJECTid
        {
            get
            {
                return ProjectId;

            }
            set
            {
                ProjectId = value;
            }
        }

        public int ROLEid
        {
            get
            {
                return RoleId;

            }
            set
            {
                RoleId = value;
            }
        }

        public string EMPname
        {
            get
            {
                return EmpName;

            }
            set
            {
                EmpName = value;
            }
        }

        public string EMPadd
        {
            get
            {
                return EmpAdd;

            }
            set
            {
                EmpAdd = value;
            }
        }

        public string Emailid
        {
            get
            {
                return emailId;

            }
            set
            {
                emailId = value;
            }
        }

        public string DEPTname
        {
            get
            {
                return DeptName;

            }
            set
            {
                DeptName = value;
            }
        }

        public string ROLEname
        {
            get
            {
                return RoleName;

            }
            set
            {
                RoleName = value;
            }
        }

        public string DEPTdescription
        {
            get
            {
                return DeptDescription;

            }
            set
            {
                DeptDescription = value;
            }
        }

        public string PROJname
        {
            get
            {
                return ProjName;

            }
            set
            {
                ProjName = value;
            }
        }

        public string PROJdescription
        {
            get
            {
                return ProjDescription;

            }
            set
            {
                ProjDescription = value;
            }
        }

        public string ROLEDescription
        {
            get
            {
                return RoleDescription;

            }
            set
            {
                RoleDescription = value;
            }
        }

        public string PHONEno
        {
            get
            {
                return PhoneNo;

            }
            set
            {
                PhoneNo = value;
            }
        }

        public DateTime DOB
        {
            get
            {
                return Dob;
            }
            set
            {
                Dob = value;
            }
        }

        public DateTime JoiningDate
        {
            get
            {
                return DateofJoining;
            }
            set
            {
                DateofJoining = value;
            }
        }

        public EmployeeEnity()
        {
            Empid = 0;
            KinId = 0;
            DeptId = 0;
            ProjectId = 0; 
            RoleId = 0;
            EmpName = string.Empty;
            EmpAdd = string.Empty;
            emailId = string.Empty;
            DeptName = string.Empty;
            RoleName = string.Empty;
            DeptDescription = string.Empty;
            ProjName = string.Empty;
            ProjDescription = string.Empty;
            RoleDescription = string.Empty;
            PhoneNo = string.Empty;
            Dob = DateTime.MinValue;
            DateofJoining = DateTime.MinValue;
        }
    }
}
