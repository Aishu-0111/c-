﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_entity;

namespace EMS_Exception
{
    public class ExceptionHandler : ApplicationException
    {
        public ExceptionHandler() : base()
        {

        }

        public ExceptionHandler(string message) : base(message)
        {

        }

        public ExceptionHandler(string message , Exception innerexception) : base(message , innerexception)
        {

        }
    }
}
