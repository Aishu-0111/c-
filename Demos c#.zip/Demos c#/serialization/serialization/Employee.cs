﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serialization
{
    [Serializable]

    public class Employee
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int desgId { get; set; }

        public int deptId { get; set; }
    }
}
