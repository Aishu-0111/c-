﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Xml.Serialization;

namespace serialization
{
    class Program
    {
            static Employee objEmp;

            static void Main(string[] args)
            {
                FillEmployee();
                //BinaryserializationDemo();
                //BinaryDeserializationDemo();
                SoapserializationDemo();
                SoapDeserializationDemo();
                //XMLSerializationDemo();
                //XMLDeserializationDemo();
            }

            static void BinaryserializationDemo()
            {
                FileStream objfs = new FileStream(@"D:\Serial\Binaryser.dat",FileMode.Create,FileAccess.Write,FileShare.Read);
                BinaryFormatter objbinf = new BinaryFormatter();
                objbinf.Serialize(objfs,objEmp);
                objfs.Close();
            }

            static void BinaryDeserializationDemo()
            {
                FileStream objfs = new FileStream(@"D:\Serial\Binaryser.dat", FileMode.Open, FileAccess.Read, FileShare.Read);
                BinaryFormatter objbinf = new BinaryFormatter();
                Employee objempNew = objbinf.Deserialize(objfs) as Employee;
                objfs.Close();
                Console.WriteLine("**Binary De-Serialzation**");
                Console.WriteLine("*Employee Details*");
                Console.WriteLine("Id : {0} , Name : {1} , Designation_Id : {2} , Department_Id : {3}" , objEmp.Id , objEmp.Name , objEmp.desgId , objEmp.deptId);
                Console.ReadLine();
            }

            static void SoapserializationDemo()
            {
                FileStream objs = new FileStream(@"D:\Serial\Soapser.xml", FileMode.Create, FileAccess.Write, FileShare.Read);
                SoapFormatter objsf = new SoapFormatter();
                objsf.Serialize(objs, objEmp);
                objs.Close();
            }

            static void SoapDeserializationDemo()
            {
                FileStream objfs = new FileStream(@"D:\Serial\Soapser.xml", FileMode.Open, FileAccess.Read, FileShare.Read);
                SoapFormatter objsdf = new SoapFormatter();
                Employee objempNew = objsdf.Deserialize(objfs) as Employee;
                objfs.Close();
                Console.WriteLine("**Soap De-Serialzation**");
                Console.WriteLine("*Employee Details*");
                Console.WriteLine("Id : {0} , Name : {1} , Designation_Id : {2} , Department_Id : {3}", objEmp.Id, objEmp.Name, objEmp.desgId, objEmp.deptId);
            }

            static void XMLSerializationDemo()
            {
                FileStream objs = new FileStream(@"D:\Serial\Xmlser.xml", FileMode.Create, FileAccess.Write, FileShare.Read);
                XmlSerializer objxs = new XmlSerializer(typeof(Employee));
                objxs.Serialize(objs, objEmp);
                objs.Close();
            }

            static void XMLDeserializationDemo()
            {
                FileStream objfs = new FileStream(@"D:\Serial\xmlpser.xml", FileMode.Open, FileAccess.Read, FileShare.Read);
                XmlSerializer objdx = new XmlSerializer(typeof(Employee));
                Employee objempNew = objdx.Deserialize(objfs) as Employee;
                objfs.Close();
                Console.WriteLine("**Xml De-Serialzation**");
                Console.WriteLine("*Employee Details*");
                Console.WriteLine("Id : {0} , Name : {1} , Designation_Id : {2} , Department_Id : {3}", objEmp.Id, objEmp.Name, objEmp.desgId, objEmp.deptId);
            }

            static void FillEmployee()
            {
                objEmp = new Employee();
                objEmp.Id = 101;
                objEmp.Name = "aishu";
                objEmp.desgId = 123;
                objEmp.deptId = 11;
            }
    }
}
