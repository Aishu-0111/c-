﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS.BUSINESS;
using HRDS.ENTITY;
using HRDS.EXCEPTION;

namespace HRDS.presentation
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1 :
                        Addemp();
                        break;
                    case 2 :
                        Updateemp();
                        break;
                    case 3 :
                        Deleteemp();
                        break;
                    case 4 :
                        Searchemp();
                        break;
                    case 5 :
                        GetListemp();
                        break;
                    case 6:
                        SerializeEmp();
                        break;
                    case 7:
                        DeSerializeEmp();
                        break;
                    case 8:
                        Environment.Exit(0);
                        break;
                    default :
                        Console.WriteLine("Invalid Choice!!!");
                        break;
                }
            } while (choice != 0);
        }

        private static void Addemp()
        {
            try
            {
                empEntity objen = new empEntity();
                Console.WriteLine("Enter employee Id : ");
                objen.Id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter employee Name : ");
                objen.Name = Console.ReadLine();
                Console.WriteLine("Enter Department Id : ");
                objen.DeptId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Designation Id : ");
                objen.DesgId = Convert.ToInt32(Console.ReadLine());
                bool empadded = empBusiness.AddempBl(objen);
                if(empadded)
                {
                    Console.WriteLine("\nEmployee added successfully!!");
                }
                else
                {
                    Console.WriteLine("\nEmployee could not be added");
                }
            }
            catch(empException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }

        private static void Updateemp()
        {
            try
            {
                Console.WriteLine("Enter employee Id you want to update : ");
                int id = Convert.ToInt32(Console.ReadLine());
                empEntity objen = empBusiness.SearchempBl(id);
                if (objen != null)
                {
                    Console.WriteLine("\nEnter employee name : ");
                    objen.Name = Console.ReadLine();
                    Console.WriteLine("\nEnter Designation Id : ");
                    objen.DesgId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("\nEnter Department Id : ");
                    objen.DeptId = Convert.ToInt32(Console.ReadLine());
                    bool empupdate = empBusiness.UpdateempBl(objen);
                    if (empupdate)
                    {
                        Console.WriteLine("\nEmployee details updated successfully!!");
                    }
                    else
                    {
                        Console.WriteLine("\nEmployee details could not be updated !!");
                    }
                }
                else
                {
                    Console.WriteLine("\nNo Employee available");
                }
            }
            catch (empException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }

        private static void Deleteemp()
        {
            try
            {
                Console.WriteLine("Enter employee Id you want to delete : ");
                int id = Convert.ToInt32(Console.ReadLine());
                empEntity objen = empBusiness.SearchempBl(id);
                if (objen != null)
                {
                    bool empdelete = empBusiness.DelempBl(id);
                    if (empdelete)
                    {
                        Console.WriteLine("\nEmployee details deleted successfully!!");
                    }
                    else
                    {
                        Console.WriteLine("\nEmployee details could not be deleted !!");
                    }
                }
                else
                {
                    Console.WriteLine("\nNo Employee available");
                }
            }
            catch (empException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }

        private static void Searchemp()
        {
            try
            {
                Console.WriteLine("Enter employee Id you want to search : ");
                int id = Convert.ToInt32(Console.ReadLine());
                empEntity objen = empBusiness.SearchempBl(id);
                if (objen != null)
                {
                    Console.WriteLine("Id \tName \tDesignation Id \tDepartment Id\n");
                    Console.WriteLine("{0} \t{1} \t{1} \t{2}",objen.Id,objen.Name,objen.DesgId,objen.DeptId);
                }
                else
                {
                    Console.WriteLine("\nNo Employee available");
                }
            }
            catch (empException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }

        private static void GetListemp()
        {
            try
            {
                List<empEntity> list = new List<empEntity>();
                if(list != null)
                {
                    Console.WriteLine("Id \tName \tDesignation Id \tDepartment Id\n");
                    foreach (empEntity emp in list)
                    {
                        Console.WriteLine("{0} \t{1} \t{1} \t{2}", emp.Id, emp.Name, emp.DesgId, emp.DeptId);
                    }
                    Console.WriteLine(" ");
                }
                else
                {
                    Console.WriteLine("List is empty");
                }
            }
            catch (empException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }

        private static void SerializeEmp()
        {
            bool empserial = empBusiness.SerializeBl();
            try
            {
                if(empserial == true)
                {
                    Console.WriteLine("Successfully serialized!!!");
                }
                else
                {
                    Console.WriteLine("Serialization unsuccessful!!!");
                }
            }
            catch(empException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeSerializeEmp()
        {
            try
            {
                List<empEntity> empdeserial = empBusiness.DeSerializeBl();
                foreach(empEntity emp in empdeserial)
                {
                    Console.WriteLine("{0} \t{1} \t{2} \t{3}", emp.Id, emp.Name, emp.DesgId, emp.DeptId);
                }
            }
            catch (empException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void PrintMenu()
        {
            Console.WriteLine("\n**Employee Details**\n");
            Console.WriteLine("Press 1 for Adding Employee");
            Console.WriteLine("Press 2 for Updating Employee");
            Console.WriteLine("Press 3 for Deleting Employee");
            Console.WriteLine("Press 4 for Searching Employee");
            Console.WriteLine("Press 5 for Getting list of all employee");
            Console.WriteLine("Press 6 for Serialize");
            Console.WriteLine("Press 7 for DeSerialize");
            Console.WriteLine("Press 8 for Exit");
        }

    }
}
