﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS.DATA_ACCESS;
using HRDS.ENTITY;
using HRDS.EXCEPTION;

namespace HRDS.BUSINESS
{
    public class empBusiness
    {
        public static bool validateEmp(empEntity objemp)
        {
            StringBuilder sb = new StringBuilder();
            bool validemp = true;
            if (objemp.Id <= 0)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Employee ID cannot be less then or equal to zero !!!");
            }
            if (objemp.Name == String.Empty)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Employee name cannot be empty!!!");
            }
            if (Convert.ToString(objemp.DesgId).Length < 4)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Designaion ID must be of 4 digit !!!");
            }
            if (Convert.ToString(objemp.DesgId).Length < 4)
            {
                validemp = false;
                sb.Append(Environment.NewLine + "Department ID must be of 4 digit !!!");
            }
            if(validemp == false)
            {
                throw new empException(sb.ToString());
            }
            return validemp;
        }

        public static bool AddempBl(empEntity objemp)
        {
            bool empadded = false;
            try
            {
                if (validateEmp(objemp))
                {
                    empDAL empd = new empDAL();
                    empadded = empd.AddempDAL(objemp);                    
                }
            }
            catch(empException)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return empadded;
        }

        public static bool UpdateempBl(empEntity objupdate)
        {
            bool empupdated = false;
            try
            {
                if (validateEmp(objupdate))
                {
                    empDAL empd = new empDAL();
                    empupdated = empd.UpdateempDAL(objupdate);                    
                }
            }
            catch (empException )
            {
                throw ;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return empupdated;
        }

        public static bool DelempBl(int empid)
        {
            bool empdeleted = false;
            try
            {
                if (empid > 0 )
                {
                    empDAL empd = new empDAL();
                    empdeleted = empd.DelempDAL(empid);
                }
                else
                {
                    throw new empException("Invalid Employee!!!");
                }
            }
            catch (empException)
            {
                throw ;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empdeleted;
        }

        public static empEntity SearchempBl(int empid)
        {
            empEntity objemp = new empEntity();
            // empEntity objem = null;
            try
            {
                if(empid > 0)
                {
                    empDAL objdal = new empDAL();
                    objemp = objdal.SearchempDAL(empid);
                }
                else
                {
                    throw new empException("Employe cannot be zero !!!");
                }
            }
            catch(empException)
            {
                throw ;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return objemp;
        }
        
        public static List<empEntity> GetemplistBl()
        {
            List<empEntity> emplistBl = null;
            try
            {
                empDAL objlist = new empDAL();
                emplistBl = objlist.GetemplistDAL();
            }
            catch (empException)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return emplistBl;
        }
        
        public static bool SerializeBl()
        {
            bool guestserialized = false;          
            empDAL objemp = new empDAL();
            guestserialized = objemp.Serializedal();           
            return guestserialized;
        }

        public static List<empEntity> DeSerializeBl()
        {          
            empDAL objemp = new empDAL();
            List<empEntity> deser = objemp.DeSerializedal();
            return deser;
        }
    }
}
