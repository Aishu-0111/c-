﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eventdemo
{
    class Axisbank
    {
        static void Main(string[] args)
        {
            RBI objRbi = new RBI(500000);
            objRbi.underbal += new AccountHandler(AxisPolicies.Penalty);
            objRbi.overbal += new AccountHandler(AxisPolicies.PayTax);
            //objRbi.withdraw(499600);
            objRbi.deposit(600000);
        }
    }

    internal class AxisPolicies
    {
        internal static void Penalty()
        {
            Console.WriteLine("\nPlease pay your penalty within time, regards Axis Bank");
            Console.ReadLine();
        }

        internal static void PayTax()
        {
            Console.WriteLine("\nPlease pay your tax within time, regards Axis Bank");
            Console.ReadLine();
        }       
    }
}
