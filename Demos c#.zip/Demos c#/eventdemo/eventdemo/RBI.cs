﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eventdemo
{
    delegate void AccountHandler();

    internal class RBI
    {
        int _bal;
        internal event AccountHandler underbal;
        internal event AccountHandler overbal;

        internal RBI(int bal)
        {
            _bal = bal;
        }

        internal void withdraw(int amt)
        {
            _bal = _bal - amt;
            if( _bal < 500 )
            {
                underbal();
            }
        }

        internal void deposit(int _amt)
        {
            _bal = _bal + _amt;
            if( _bal > 100000 )
            {
                overbal();
            }
        }
    }
}
