﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace file_demo
{
    class Program
    {
        static void Main(string[] args)
        {
            //CreateFileWith_FileStream();
            //ReadFileWith_StreamReader();
            //WriteFileWith_StreamWriter();
            //CreateFile_usingFileClass();
            //MoveFile_usingFileClass();
            //CreateFile_usingFileInfoClass();
            //MoveFile_usingFileInfoClass();
            //CreateDir_uisngDirclass();
            //CreateDir_uisngDirInfoclass();
            getfiles_frmdir();
        }

        static void CreateFileWith_FileStream()
        {
            FileStream objfs = new FileStream(@"D:\file io\Demo.Txt", FileMode.Create, FileAccess.Write, FileShare.Read);
            objfs.Close();
        }

        static void ReadFileWith_StreamReader()
        {
            FileStream objSr = new FileStream(@"D:\file io\Demo.Txt", FileMode.Open, FileAccess.Read, FileShare.Read);
            StreamReader objR = new StreamReader(objSr);
            Console.WriteLine("Data from file : \n");
            string data = objR.ReadLine();
            objR.Close();
            objSr.Close();
            Console.WriteLine("Data " + data);
            Console.ReadLine();
        }

        static void WriteFileWith_StreamWriter()
        {
            FileStream objSw = new FileStream(@"D:\file io\Demo.Txt", FileMode.Append, FileAccess.Write, FileShare.Read);
            StreamWriter objS = new StreamWriter(objSw);
            Console.WriteLine("Enter the data : ");
            objS.WriteLine(Console.ReadLine());
            objS.Flush();
            objS.Close();
            objSw.Close();
        }

        static void CreateFile_usingFileClass()
        {
            string file = @"D:\file io\Demo1.Txt";
            if (!File.Exists(file))
            {
                FileStream objfs = File.Create(file);
                if (objfs != null)
                {
                    Console.WriteLine("File created successfully");
                }
            }
        }

        static void MoveFile_usingFileClass()
        {
            string file = @"D:\file io\Demo1.Txt";
            string dest = @"D:\file io\Dest\Demo1.Txt";
            if (File.Exists(file))
            {
                File.Move(file, dest);
                if (File.Exists(dest))
                {
                    Console.WriteLine("File moved successfully");
                }
                else
                {
                    Console.WriteLine("File could not be moved");
                }
                Console.ReadLine();
            }
        }

        static void CreateFile_usingFileInfoClass()
        {
            string file = @"D:\file io\Demo2.Txt";
            FileInfo objfi = new FileInfo(file);
            if (!objfi.Exists)
            {
                objfi.Create();
                if (objfi != null)
                {
                    Console.WriteLine("File created successfully");
                }
                else
                {
                    Console.WriteLine("File could not be created");
                }
            }
        }

        static void MoveFile_usingFileInfoClass()
        {
            string file = @"D:\file io\Demo2.Txt";
            string dest = @"D:\file io\Dest\Demo2.Txt";
            FileInfo objfi = new FileInfo(file);
            if (objfi.Exists)
            {
                objfi.MoveTo(dest);
                if (File.Exists(dest))
                {
                    Console.WriteLine("File moved successfully");
                }
                else
                {
                    Console.WriteLine("File could not be moved");
                }
                Console.ReadLine();
            }
        }

        static void CreateDir_uisngDirclass()
        {
            string objdp = @"D:\file io\dir";
            if (!Directory.Exists(objdp))
            {
                Directory.CreateDirectory(objdp);
                if (Directory.Exists(objdp))
                {
                    Console.WriteLine("Directory is Created");
                }
                else
                {
                    Console.WriteLine("Directory could not be created");
                }
            }
        }

        static void CreateDir_uisngDirInfoclass()
        {
            string objdp = @"D:\file io\dir2";
            DirectoryInfo objdi = new DirectoryInfo(objdp);
            if (!objdi.Exists)
            {
                objdi.Create();
                if (Directory.Exists(objdp))
                {
                    Console.WriteLine("Directory is Created");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Directory could not be created");
                    Console.ReadLine();

                }
            }
        }

        static void getfiles_frmdir()
        {
            string str = @"D:\file io\dir2";
            if (Directory.Exists(str))
            {
                string[] strf = Directory.GetFiles(str);
                Console.WriteLine("**List of files**");
                foreach (string strfi in strf)
                {
                    string strfn = Path.GetFileName(strfi);
                    Console.WriteLine(strfn);
                    string strfne = Path.GetFileNameWithoutExtension(strfi);
                    Console.WriteLine(strfne);
                }
            }
        }
    }
}
