﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops_demo1
{
    class Shape
    {
        int area;
        int perimeter;

        public int Area
        {
            get
            {
                return area;
            }
            set
            {
                area = value;
            }
        }

        public int Perimeter
        {
            get
            {
                return perimeter;
            }
            set
            {
                perimeter = value;
            }
        }

        public Shape()
        {

        }

        internal void Display()
        {

        }

        internal virtual void ARea()
        {

        }
        
        internal virtual void PErimeter()
        {

        }
    }
}
