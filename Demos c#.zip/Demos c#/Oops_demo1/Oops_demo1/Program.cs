﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oops_demo1
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle obj = new Rectangle();
            square objS = new square();
            obj.Length = 100;
            obj.Breadth = 40;
            objS.Side = 2;
            obj.ARea();
            obj.PErimeter();
           // objS.ARea();
           // objS.PErimeter();
            Console.WriteLine("The area of rectangle is " + obj.Area);
            Console.WriteLine("The perimeter of rectangle is " + obj.Perimeter);
           // Console.WriteLine("The area of square is " + obj.Area);
           // Console.WriteLine("The perimeter of square is " + obj.Perimeter);
            obj.Display();
            Console.ReadLine();
            DisplayAreaofShapes(obj);
            DisplayAreaofShapes(objS);
        }

        static void DisplayAreaofShapes(Shape objsh)
        {

        }
    }
}
