﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oop_demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle obj = new Rectangle();
            obj.Length = 100;
            obj.Breadth = 40;
            obj.ARea();
            obj.PErimeter();
            Console.WriteLine("The area of rectangle is " + obj.Area);
            Console.WriteLine("The perimeter of rectangle is " + obj.Perimeter);
            Console.ReadLine();
        }
    }
}
