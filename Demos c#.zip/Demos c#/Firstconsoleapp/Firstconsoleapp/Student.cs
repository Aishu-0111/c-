﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firstconsoleapp
{
        internal struct Student
        {
            internal int rollno;
            internal string name;
            internal string grade;

            public Student(int rollno, string name, string grade)
            {
                this.rollno = rollno;
                this.name = name;
                this.grade = grade;
            }
        }
}
