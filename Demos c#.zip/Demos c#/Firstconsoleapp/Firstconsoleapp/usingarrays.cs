﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Firstconsoleapp
{
    class usingarrays
    {
        static void Main(string[] args)
        {
            SingleDarray();
            MultiDarray();
        }

        static void SingleDarray()
        {
            string[] strcities = new string[4];
            strcities[0] = "Mumbai";
            strcities[1] = "Chennai";
            strcities[2] = "Bangalore";
            strcities[3] = "Kerala";
            Console.WriteLine("***List of cities using for loop***\n");
            for (int i = 0; i < strcities.Length; i++)
            {
                Console.WriteLine(strcities[i]);
                Console.ReadLine();
            }
            Console.WriteLine("***List of cities using for each loop***\n");
            foreach(string i in strcities)
            {
                Console.WriteLine(i);
                Console.ReadLine();

            }
        }

        static void MultiDarray()
        {
            int[,] numbers = new int[2,2];
            numbers[0, 0] = 101;
            numbers[0, 1] = 201;
            numbers[1, 0] = 301;
            numbers[1, 1] = 401;
            Console.WriteLine("**Two Dimensional Array**\n");
            for(int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Console.WriteLine(numbers[i,j]);
                    Console.ReadLine();
                }
            }
        }

    }
}
