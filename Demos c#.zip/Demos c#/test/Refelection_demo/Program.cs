﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
namespace Refelection_demo
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Type type = typeof(sample_Refelection);

            Console.WriteLine("--Methods--");
            MethodInfo[] methods = type.GetMethods();
            foreach (MethodInfo method in methods)
            {
                Console.WriteLine(method.Name);
            }

            Console.WriteLine("--properties--");
            PropertyInfo[] properties = type.GetProperties();
            foreach (PropertyInfo property in properties)
            {
                Console.WriteLine(property.Name);
            }

            Console.WriteLine("--fields--");
            FieldInfo[] fields = type.GetFields();
            foreach (FieldInfo field in fields)
            {
                Console.WriteLine(field.Name);
            }
            Console.ReadKey();
        }

         public class sample_Refelection
        {
            public int id =1;
            public string name = "Anand";
            public int ID { get { return id; } set { value = id; } }
            public String Name { get { return name; } set { value = name; } }
        }
        
            
    
    }

}


