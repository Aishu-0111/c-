﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculatorlib
{
    public class calculator
    {
        public int Addition(int a, int b)
        {
            int result;
            result = a + b;
            return result;
        }
        public int Sub(int a, int b)
        {
            int result;
            result = a - b;
            return result;
        }
        public int Multi(int a, int b)
        {
            int result;
            result = a * b;
            return result;
        }
        public int div(int a, int b)
        {

            int result;
            result = a / b;
            return result;
        }
    }
}
