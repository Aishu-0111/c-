﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class structprg
    {
        static void Main(String[] args) {
            usingstruct obj = new usingstruct(1,"Amanda","10th A");
            Console.WriteLine("Roll no:{0} , Name:{1} , Grade:{2} ", obj.rollno, obj.name, obj.grade);
            Console.ReadKey();
        }
    }
}
