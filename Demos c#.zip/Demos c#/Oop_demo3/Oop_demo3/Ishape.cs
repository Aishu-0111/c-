﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oop_demo3
{
    interface Ishape
    {
            int Area
            {
                get;
                set;
            }

            int Perimeter
            {
                get;
                set;             
            }

            void ARea();
            void PErimeter();
     }
}

