﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oop_demo3
{
    static class Database
    {
        public static string ConnectionString
        {
            get
            {
                return "server = .;database = employeemgmt; integrated security = true";
            }
        }
    }
}
