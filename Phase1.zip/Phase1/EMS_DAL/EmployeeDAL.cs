﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_entity;
using EMS_Exception;

namespace EMS_DAL
{
    public class EmployeeDAL
    {
        public static List<EmployeeEnity> emplist = new List<EmployeeEnity>();

        public bool AddEmpDal(EmployeeEnity addemp)
        {
            bool employeeAdded = false;
            try
            {
                emplist.Add(addemp);
                employeeAdded = true;
            }
            catch (SystemException ex)
            {
                throw new ExceptionHandler(ex.Message);
            }
            return employeeAdded;
        }

        public bool UpdateEmpDal(EmployeeEnity updateemp)
        {
            bool employeeUpdated = false;
            try
            {
               for(int i = 0; i < emplist.Count; i++)
                {
                    if(emplist[i].KINid == updateemp.KINid)
                    {
                        updateemp.EMPid = emplist[i].EMPid;
                        updateemp.EMPname = emplist[i].EMPname;
                        updateemp.PHONEno = emplist[i].PHONEno;
                        updateemp.DOB = emplist[i].DOB;
                        updateemp.JoiningDate = emplist[i].JoiningDate;
                        updateemp.EMPadd = emplist[i].EMPadd;
                        updateemp.Emailid = emplist[i].Emailid;
                        updateemp.DEPTid = emplist[i].DEPTid;
                        updateemp.DEPTname = emplist[i].DEPTname;
                        updateemp.DEPTdescription = emplist[i].DEPTdescription;
                        updateemp.PROJECTid = emplist[i].PROJECTid;
                        updateemp.PROJname = emplist[i].PROJname;
                        updateemp.PROJdescription = emplist[i].PROJdescription;
                        updateemp.ROLEid = emplist[i].ROLEid;
                        updateemp.ROLEname = emplist[i].ROLEname;
                        updateemp.ROLEDescription = emplist[i].ROLEDescription;
                        employeeUpdated = true;
                    }
                }
                employeeUpdated = true;
            }
            catch (SystemException ex)
            {
                throw new ExceptionHandler(ex.Message);
            }
            return employeeUpdated;
        }

        public bool DeleteEmpDal(int deleteid)
        {
            bool employeeDeleted = false;
            try
            {
                EmployeeEnity objentity = emplist.Find(emp => emp.KINid == deleteid);
                if(objentity != null)
                {
                    emplist.Remove(objentity);
                    employeeDeleted = true;
                }
            }
            catch (SystemException ex)
            {
                throw new ExceptionHandler(ex.Message);
            }
            return employeeDeleted;
        }

        public EmployeeEnity SearchEmpDAL(int searchid)
        {
            EmployeeEnity searchemployee = null;
            try
            {
                searchemployee = emplist.Find(employee => employee.KINid == searchid);
            }
            catch(SystemException ex)
            {
                throw new ExceptionHandler(ex.Message);
            }
            return searchemployee;
        }

        public List<EmployeeEnity> ViewEmpDAL()
        {
            return emplist;
        }

    }
}
