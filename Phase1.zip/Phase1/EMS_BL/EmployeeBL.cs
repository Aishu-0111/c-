﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_entity;
using EMS_Exception;
using EMS_DAL;
using System.Text.RegularExpressions;

namespace EMS_BL
{
    public class EmployeeBL
    {
        private static bool ValidateEmp(EmployeeEnity objemp)
        {
            StringBuilder sb = new StringBuilder();
            bool validemployee = true;          
            if (objemp.PHONEno.Length < 10)
            {
                validemployee = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }

            if (validemployee == false)
            {
                throw new ExceptionHandler(sb.ToString());
            }

            return validemployee;
        }

        public static bool AddEmpBl(EmployeeEnity add)
        {
            bool empadded = false;
            try
            {
                if (ValidateEmp(add))
                {
                    EmployeeDAL addemp = new EmployeeDAL();
                    empadded = addemp.AddEmpDal(add);
                }
                else
                {
                    throw new ExceptionHandler("Enter Valid Details");
                }
            }
            catch (ExceptionHandler)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empadded;
        }

        public static bool UpddateEmpBl(EmployeeEnity update)
        {
            bool empupdated = false;
            try
            {
                if (ValidateEmp(update))
                {
                    EmployeeDAL updateemp = new EmployeeDAL();
                    empupdated = updateemp.UpdateEmpDal(update);
                }
                else
                {
                    throw new ExceptionHandler("Enter Valid Id");
                }
            }
            catch (ExceptionHandler)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empupdated;
        }

        public static bool DeleteEmpBl(int delete)
        {
            bool empdeleted = false;
            try
            {
                if (delete > 0)
                {
                    EmployeeDAL delemp = new EmployeeDAL();
                    empdeleted = delemp.DeleteEmpDal(delete);
                }
                else
                {
                    throw new ExceptionHandler("Invalid Employee !!!");
                }
            }
            catch (ExceptionHandler)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empdeleted;
        }

        public static EmployeeEnity SearchEmpBl(int search)
        {
            EmployeeEnity searchemployee = null;
            try
            {
                EmployeeDAL emp = new EmployeeDAL();
                searchemployee = emp.SearchEmpDAL(search);            
            }
            catch (ExceptionHandler)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchemployee;
        }

        public static List<EmployeeEnity> ViewEmpBL()
        {
            List<EmployeeEnity> list = null;
            try
            {
                EmployeeDAL listemp = new EmployeeDAL();
                list = listemp.ViewEmpDAL();
            }
            catch (ExceptionHandler)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return list;
        }

    }
}
