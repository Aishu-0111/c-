﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_entity;
using EMS_Exception;
using EMS_DAL;
using EMS_BL;

namespace EMS_PRESENTATION
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            char option;
            do
            {
                Printmenu();
                Console.WriteLine("\nEnter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1 :
                        Add();
                        break;
                    case 2 :
                        Update();
                        break;
                    case 3 :
                        Delete();
                        break; 
                    case 4 :
                        Search();
                        break;
                    case 5 :
                        View();
                        break;
                    case 6 :
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("\nPress 'y' to continue..");
                option = Convert.ToChar(Console.ReadLine());
            } while (option == 'y');
        }

        private static void Printmenu()
        {
            Console.WriteLine("***Employee Details***");
            Console.WriteLine("\nPress 1 for adding employee");
            Console.WriteLine("Press 2 for updating employee");
            Console.WriteLine("Press 3 for deleting employee");
            Console.WriteLine("Press 4 for searching employee");
            Console.WriteLine("Press 5 for viewing employee");
            Console.WriteLine("Press 6 for exit");
        }

        private static void Add()
        {
            try
            {
                EmployeeEnity objadd = new EmployeeEnity();
                Console.WriteLine("Enter Kin Id : ");
                objadd.KINid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Employee Id : ");
                objadd.EMPid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Employee Name : ");
                objadd.EMPname = Console.ReadLine();
                Console.WriteLine("Enter Contact no : ");
                objadd.PHONEno = Console.ReadLine();
                Console.WriteLine("Enter Date of Birth : ");
                objadd.DOB = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Date of Joining : ");
                objadd.JoiningDate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Employee Address : ");
                objadd.EMPadd = Console.ReadLine();
                Console.WriteLine("Enter Email Id : ");
                objadd.Emailid = Console.ReadLine();

                Console.WriteLine("Enter Department Id : ");
                objadd.DEPTid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Department Name : ");
                objadd.DEPTname = Console.ReadLine();
                Console.WriteLine("Enter Department Description : ");
                objadd.DEPTdescription = Console.ReadLine();

                Console.WriteLine("Enter Project Id : ");
                objadd.PROJECTid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Project Name : ");
                objadd.PROJname = Console.ReadLine();
                Console.WriteLine("Enter Project Description : ");
                objadd.PROJdescription = Console.ReadLine();

                Console.WriteLine("Enter Role Id : ");
                objadd.ROLEid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Role Name : ");
                objadd.ROLEname = Console.ReadLine();
                Console.WriteLine("Enter Role Description : ");
                objadd.ROLEDescription = Console.ReadLine();

                bool empAdded = EmployeeBL.AddEmpBl(objadd);
                if (empAdded)
                    Console.WriteLine("Employee added successfully");
                else
                    Console.WriteLine("Employee could not be added");

            }
            catch (ExceptionHandler ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void Update()
        {

            try
            {
                int updateID;
                Console.WriteLine("Enter KinId to Update Details:");
                updateID = Convert.ToInt32(Console.ReadLine());
                EmployeeEnity updateemp = EmployeeBL.SearchEmpBl(updateID);
                if (updateemp != null)
                {
                    Console.WriteLine("Enter Employee Id : ");
                    updateemp.EMPid = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Employee Name : ");
                    updateemp.EMPname = Console.ReadLine();
                    Console.WriteLine("Enter Contact no : ");
                    updateemp.PHONEno = Console.ReadLine();
                    Console.WriteLine("Enter Date of Birth : ");
                    updateemp.DOB = Convert.ToDateTime(Console.ReadLine());
                    Console.WriteLine("Enter Date of Joining : ");
                    updateemp.JoiningDate = Convert.ToDateTime(Console.ReadLine());
                    Console.WriteLine("Enter Employee Address : ");
                    updateemp.EMPadd = Console.ReadLine();
                    Console.WriteLine("Enter Email Id : ");
                    updateemp.Emailid = Console.ReadLine();

                    Console.WriteLine("Enter Department Id : ");
                    updateemp.DEPTid = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Department Name : ");
                    updateemp.DEPTname = Console.ReadLine();
                    Console.WriteLine("Enter Department Description : ");
                    updateemp.DEPTdescription = Console.ReadLine();

                    Console.WriteLine("Enter Project Id : ");
                    updateemp.PROJECTid = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Project Name : ");
                    updateemp.PROJname = Console.ReadLine();
                    Console.WriteLine("Enter Project Description : ");
                    updateemp.PROJdescription = Console.ReadLine();

                    Console.WriteLine("Enter Role Id : ");
                    updateemp.ROLEid = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Role Name : ");
                    updateemp.ROLEname = Console.ReadLine();
                    Console.WriteLine("Enter Role Description : ");
                    updateemp.ROLEDescription = Console.ReadLine();

                    bool empUpdated = EmployeeBL.UpddateEmpBl(updateemp);
                    if (empUpdated)
                        Console.WriteLine("Employee Details Updated");
                    else
                        Console.WriteLine("Employee Details could not be Updated ");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }
            }
            catch (ExceptionHandler ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private static void Delete()
        {
            try
            {
                int deleteID;
                Console.WriteLine("Enter KinId to Delete:");
                deleteID = Convert.ToInt32(Console.ReadLine());
                EmployeeEnity delete = EmployeeBL.SearchEmpBl(deleteID);
                if (delete != null)
                {
                    bool empdeleted = EmployeeBL.DeleteEmpBl(deleteID);
                    if (empdeleted)
                        Console.WriteLine("Employee Deleted");
                    else
                        Console.WriteLine("Employee could not be Deleted ");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }
            }
            catch (ExceptionHandler ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void Search()
        {
            try
            {
                int searchID;
                Console.WriteLine("Enter KinId to Search : ");
                searchID = Convert.ToInt32(Console.ReadLine());
                EmployeeEnity searchemp = EmployeeBL.SearchEmpBl(searchID);
                if (searchemp != null)
                {
                    Console.WriteLine("KinId\t\tEmailId\t\tEmployeeName\t\tRoleName\t\tDepartmentName\t\tProjectname");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t\t{4}\t\t\t{5}", searchemp.KINid, searchemp.Emailid, searchemp.EMPname, searchemp.ROLEname, searchemp.DEPTname, searchemp.PROJname);
                }           
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }

            }
            catch (ExceptionHandler ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void View()
        {
            try
            {
                List<EmployeeEnity> empList = EmployeeBL.ViewEmpBL();
                if (empList != null)
                {
                    Console.WriteLine("KinId\t\tEmailId\t\tEmployeeName\t\tRoleName\t\tDepartmentName\t\tProjectname");
                    foreach (EmployeeEnity emp in empList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t\t{4}\t\t\t{5}", emp.KINid, emp.Emailid, emp.EMPname, emp.ROLEname, emp.DEPTname, emp.PROJname);
                    }
                    Console.WriteLine(" ");

                }
                else
                {
                    Console.WriteLine("No Employee details available");
                }
            }
            catch (ExceptionHandler ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        
    }
}
