﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab10b
{
    delegate int ArithmeticHandler(int n1, int n2);
    class Program
    {
        static ArithmeticHandler objAH;
        static ArithmeticOperation objAO = new ArithmeticOperation();
        static int choice;
        static void Main(string[] args)
        {
            
            char c;
            do
            {
                Console.WriteLine("Press 1 to Add Two Numbers \nPress 2 to Subtract Two Numbers \nPress 3 to Multiply Two Numbers \nPress 4 to Divide Two Numbers \nPress 5 to Find Max Between Two Numbers");
                 choice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter First Number : ");
                int n1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Second Number : ");
                int n2 = Convert.ToInt32(Console.ReadLine());
                PerformArithmeticOperation(n1, n2, objAH);
                
                Console.WriteLine("\n ==> Press 'y' to Continue, else press any Character to Exit.");
                c = Convert.ToChar(Console.ReadLine());             
            } while (c == 'y');
        }
        static void PerformArithmeticOperation(int num1, int num2, ArithmeticHandler arOperation)
        {
            if (choice == 1)
            {
                arOperation = new ArithmeticHandler(objAO.Addition);
            }
            if (choice == 2)
            {
                arOperation = new ArithmeticHandler(objAO.Subtraction);
            }
            if (choice == 3)
            {
                arOperation = new ArithmeticHandler(objAO.Multiplication);
            }
            if (choice == 4)
            {
                arOperation = new ArithmeticHandler(objAO.Division);
            }
            if (choice == 5)
            {
                arOperation = new ArithmeticHandler(objAO.MaxNumber);
            }
                  
            Console.WriteLine("output  : " + arOperation.Invoke(num1, num2));   //At one Time invoking the Delegate object
        }

    }
}
