﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab10a
{
    class Program
    {
        delegate int Arithmatic(int num1, int num2);      
        static void Main(string[] args)
        {
            Calculator obj = new Calculator();
            Console.WriteLine("Enter the two numbers:");
            int num1 = Convert.ToInt32(Console.ReadLine());
            int num2 = Convert.ToInt32(Console.ReadLine());
            Arithmatic objAdd = new Arithmatic(obj.Addition);
            int result = objAdd.Invoke(num1, num2);
            Console.WriteLine("Result of addition = " + result);
            Arithmatic objSub = new Arithmatic(obj.Subtraction);
            int result2 = objSub.Invoke(num1, num2);
            Console.WriteLine("Result of subtraction = " + result2);
            Arithmatic objmul = new Arithmatic(obj.Multiplication);
            int result3 = objmul.Invoke(num1, num2);
            Console.WriteLine("Result of multiplication = " + result3);
            Arithmatic objdiv = new Arithmatic(obj.Division);
            int result4 = objdiv.Invoke(num1, num2);
            Console.WriteLine("Result of division = " + result4);
            Arithmatic objmax = new Arithmatic(obj.Findmax);
            int result5 = objmax.Invoke(num1, num2);
            Console.WriteLine("Maximum value = " + result5);
            Console.ReadKey();
        }
    }
}
