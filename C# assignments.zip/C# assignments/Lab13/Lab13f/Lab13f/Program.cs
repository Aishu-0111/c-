﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Lab13f
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream(@"D:\abc.txt", FileMode.Create);
            BinaryFormatter formatter = new BinaryFormatter();
            Student s = new Student(1, "Aishwarya", "Mumbai", "BSc_IT");
            formatter.Serialize(fs,s);
            Console.WriteLine("Seriazition  Sucessfull!!");
            fs.Close();
            Console.ReadLine();
        }
    }
}
