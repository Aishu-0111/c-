﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab13d
{
    [Serializable]

    public class Supplier
    {
        public static Supplier obj = new Supplier();
        private string supplierName, city, phoneNo, email;
        private int supplierId;

        public int SupplierId
        {
            get
            {
                return supplierId;
            }
            set
            {
                supplierId = value;
            }
        }

        public string SupplierName
        {
            get
            {
                return supplierName;
            }
            set
            {
                supplierName = value;
            }
        }

        public string City
        {
            get
            {
                return city;
            }
            set
            {
                city = value;
            }
        }

        public string PhoneNo
        {
            get
            {
                return phoneNo;
            }
            set
            {
                phoneNo = value;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }
            set
            {
                email = value;
            }
        }

        public void AccpetDetail(Supplier obj)
        {
            SupplierId = obj.SupplierId;
            supplierName = obj.supplierName;
            city = obj.city;
            phoneNo = obj.phoneNo;
            email = obj.email;      
        }

        public Supplier DisplayDetail()
        {
            return obj;
        }
    }
}

