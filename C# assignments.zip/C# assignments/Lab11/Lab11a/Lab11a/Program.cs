﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab11a
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your name : ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter your credit card no : ");
            int no = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the amount you want to pay: " );
            int amt = Convert.ToInt32(Console.ReadLine());            
            CreditCard c = new CreditCard(no, name);
            c.makePayment += new CreditHandler(GetMessage);
            c.MakePayment(amt);
        }
        static void GetMessage()
        {
            Console.WriteLine("Successfull!!");
        }
    }
}
