﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1a
{
    class Program
    {
        static void Main(string[] args)
        {
            Employeelib.Class1[] emp = new Employeelib.Class1[2];

            for(int i = 0;i < emp.Length; i++)
            {
                emp[i] = new Employeelib.Class1();
            }

            for (int i = 0; i < emp.Length; i++)
            {
                Console.WriteLine("\nEmployee details\n");
                Console.WriteLine("Enter your employee id ");
                emp[i].Employeeid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter your Name :");
                emp[i].EmployeeName = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter your Address :");
                emp[i].EmployeeAdd = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter your City :");
                emp[i].EmployeeCity = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter your Department :");
                emp[i].EmployeeDept = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter your Salary :");
                emp[i].EmployeeSal = Convert.ToInt32(Console.ReadLine());
            }
            for (int j = 0; j < emp.Length; j++)
            {
                Console.WriteLine("\nEmployee name is " + emp[j].EmployeeName + " and his salary is " + emp[j].EmployeeSal);
            }
            Console.ReadLine();            
        }
    }
}
