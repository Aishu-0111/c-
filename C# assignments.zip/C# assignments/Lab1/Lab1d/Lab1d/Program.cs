﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1d
{
    class Program
    {
        static void Main(string[] args)
        {
            int rollNumber;
            string studentName;
            byte Age;
            char gender;           
            string address;
            float percentage;
            DateTime dateofbirth;

            Console.WriteLine("Student Detials\n");
            Console.WriteLine("\nRoll no : ");
            rollNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nName : ");
            studentName = Console.ReadLine();
            Console.WriteLine("\nAge : ");
            Age = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("\nGender : ");
            gender = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("\nDate of birth (mm/dd/yyyy): ");
            dateofbirth = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("\nAddress: ");
            address = Console.ReadLine();
            Console.WriteLine("\nPercentage : ");
            percentage = Convert.ToInt32(Console.ReadLine());
            Console.ReadLine();
        }       
    }
}
