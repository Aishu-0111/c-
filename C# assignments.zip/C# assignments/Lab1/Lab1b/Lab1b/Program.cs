﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1b
{
    class Program
    {
        static void Main(string[] args)
        {
                Console.WriteLine("***Calculator****\n");
                char choice;
                do
                {
                    Console.WriteLine(" Press 1 for Addition \n Press 2 for Subtraction \n Press 3 for Multiplication \n Press 4 for Division\n Press 5 for Modulo");
                    double operation;
                    operation = Convert.ToInt32(Console.ReadLine());
                    double firstno;
                    double secondno;
                    double result;
                    // Calculator calculator = new Calculator();
                    Clalclib.Class1 calculator = new Clalclib.Class1();
                    switch (operation)
                    {
                        case 1:
                            // Addition
                            Console.WriteLine("\nEnter First digit");
                            firstno = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("\nEnter Second digit");
                            secondno = Convert.ToDouble(Console.ReadLine());
                            result = calculator.Addition(firstno, secondno);
                            Console.WriteLine("\nAddition of two number is : " + result);
                            break;
                        case 2:
                            // Subtraction
                            Console.WriteLine("\nEnter First digit");
                            firstno = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("\nEnter Second digit");
                            secondno = Convert.ToDouble(Console.ReadLine());
                            result = calculator.Subtraction(firstno, secondno);
                            Console.WriteLine("\nSubtraction of two number is : " + result);
                            break;
                        case 3:
                            // Multiplication
                            Console.WriteLine("\nEnter First digit");
                            firstno = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("\nEnter Second digit");
                            secondno = Convert.ToDouble(Console.ReadLine());
                            result = calculator.Multiplication(firstno, secondno);
                            Console.WriteLine("\nMultiplication of two number is : " + result);
                            break;
                        case 4:
                            // division
                            Console.WriteLine("\nEnter First digit");
                            firstno = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("\nEnter Second digit");
                            secondno = Convert.ToDouble(Console.ReadLine());
                            result = calculator.Division(firstno, secondno);
                            Console.WriteLine("\nDivision of two number is : " + result);
                            break;
                        case 5:
                            // modulo
                            Console.WriteLine("\nEnter First digit");
                            firstno = Convert.ToDouble(Console.ReadLine());
                            Console.WriteLine("\nEnter Second digit");
                            secondno = Convert.ToDouble(Console.ReadLine());
                            result = calculator.Modulo(firstno, secondno);
                            Console.WriteLine("\nModulo of two number is : " + result);
                            break;
                        case 6:
                            //Exit
                            Environment.Exit(0);
                            break;
                        default:
                            // Logic to handle wrong choice
                            Console.WriteLine("\nEnter valid option");
                            break;
                    }
                    Console.WriteLine("\nDo you want to continue ? \nPress 'y' to continue or 'n' to exit");
                    choice = Convert.ToChar(Console.ReadLine());
                } while (choice == 'y');
                Console.ReadLine();
            }
        }
    }

