﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6a
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Customer obj = new Customer(100, "Aishu", "India", "Mumbai", "12345678890", 100000);
            }
             catch (InvalidCreditLimitException i)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}
