﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    public class HSBC : BankAccount
    {
        public override bool Withdraw(double amount)
        {
            if (balance - amount >= 5000)
            {
                balance = balance - amount;
                return true;
            }
            return false;
        }

        public override bool Transfer(IBankAccount toAccount, double amount)
        {
            if (Balance - amount >= 5000)
            {
                Withdraw(amount);
                toAccount.Deposit(amount);
                return true;
            }
            return false;
        }

        public void AccountType(BankAccountTypeEnum bankAccountTypeEnum)
        {
            accountType = bankAccountTypeEnum;
        }

        public override void CalculateInterest()
        {
            Console.WriteLine("HSBC rate of interest " + accountType.ToString().ToUpper() + " for your account " + Balance * 1 * 0.05);
        }
    }
}
