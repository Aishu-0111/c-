﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4a
{
    class PermanentEmployee : Employee
    {
        public int NOOFLEAVES
        {
            get;
            set;      
        }

        public int PF
        {
            get;
            set;         
        }

        public override double GetSalary()
        {
            Console.WriteLine("Enter Provident Fund:");
            PF = Convert.ToInt32(Console.ReadLine());
            double result;
            result = salary - PF;
            return result;
        }
    }
}

