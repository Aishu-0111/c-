﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4b
{
    class Program
    {
        static void Main(string[] args)
        {
                Triangle t = new Triangle();
                t.WhoamI();
                Circle c = new Circle();
                c.WhoamI();
                Console.ReadKey();           
        }
    }    
}
