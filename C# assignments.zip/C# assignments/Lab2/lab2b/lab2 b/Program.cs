﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2_b
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[5,6];

            Console.WriteLine("**Multi Dimensional Array**\n");
            Console.WriteLine("Enter elements for array :\n");
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    arr[i, j] = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine("\n");
            }
        
            Console.WriteLine("\n**Matrix Form**\n");
            for (int i = 0; i < arr.GetLength(0); i++)
            {      
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    Console.Write(arr[i, j] +"\t");
                }
                Console.WriteLine(" ");
            }
            Console.ReadLine();
        }
    }
}
