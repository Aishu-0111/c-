﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2d
{
    class Program
    {
        static void Main(string[] args)
        {
            // boxing
            object objID, objName, objPrice, objQuan;
            double AmountPayable;

            Console.WriteLine("Enter the id of product : ");
            objID = Console.ReadLine();
            Console.WriteLine("Enter the name of product : ");
            objName = Console.ReadLine();
            Console.WriteLine("Enter price : ");
            objPrice = Console.ReadLine();
            Console.WriteLine("Enter quantity : ");
            objQuan = Console.ReadLine();

            //unboxing
            int ProdID = Convert.ToInt32(objID);
            int Quantity = Convert.ToInt32(objQuan);
            int Price = Convert.ToInt32(objPrice);
            string name = Convert.ToString(objName);
            
            AmountPayable = Quantity * Price;
            
            Console.WriteLine("\n** Product Details **");
            Console.WriteLine("\nProduct ID : " + ProdID);
            Console.WriteLine("Product Name : " + name);
            Console.WriteLine("Price : " + Price);
            Console.WriteLine("Quantity : " + Quantity);
            Console.WriteLine("Amount Payable : " + AmountPayable);
            Console.ReadKey();
        }
    }
}
