﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab12a
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter the Name of the File : ");
                string fileName = Console.ReadLine();
                ReadFileWith_StreamReader(fileName);
            }
            catch (Exception e)
            {
                Console.WriteLine("Does not Find File....");
                Console.ReadKey();
            }
        }
        static void ReadFileWith_StreamReader(string fileName)
        {
            FileStream objFS = new FileStream(@"D:\file io" + fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
            StreamReader objSR = new StreamReader(objFS);
            string DataFromFile = objSR.ReadToEnd();
            objSR.Close();
            objFS.Close();
            Console.WriteLine("Data from File :" +DataFromFile);
            Console.ReadKey();
        }
    }
}
