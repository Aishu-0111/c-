﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3c
{
     public class Carsarr
    {
        static Cars[] objC = new Cars[2];
        int ctr;

        public void Addcar(Cars objcar)
        {
            objC[ctr++] = objcar;
        }

        public void Updatecar(Cars objU)
        {
            Cars objCS = Searchcar(objU.Make);
            if(objCS != null)
            {
                objCS.Model = objU.Model;
                objCS.Year = objU.Year;
                objCS.SalesPrice = objU.SalesPrice;
            }
        }

        public void Deletecar(string make)
        {
            for(int i = 0; i < objC.Length; i++)
            {
                try
                {
                    if (objC[i].Make == make)
                    {
                        objC[i] = null;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
        }

        public Cars Searchcar(string make)
        {
            foreach(Cars objS in objC)
            {
                if(objS.Make == make)
                {
                    return objS;
                }
            }
            return null;
        }

        public Cars[] Getcar()
        {
            return objC;
        }
    }
}
