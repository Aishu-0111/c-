﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3d
{
    class SupplierTest
    {
        static void Main(string[] args)
        {
            Supplier objSupplier = new Supplier();

            Console.WriteLine("===Enter Supplier Details===");
            Console.WriteLine("Enter the Supplier ID :");
            objSupplier.supplierID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the supplierName :");
            objSupplier.supplierName = Console.ReadLine();
            Console.WriteLine("Enter the city :");
            objSupplier.city = Console.ReadLine();
            Console.WriteLine("Enter the phoneNo :");
            objSupplier.phoneNo = Console.ReadLine();
            Console.WriteLine("Enter the email :");
            objSupplier.email = Console.ReadLine();

            Supplier objSupplier1 = new Supplier();

            objSupplier1.AcceptDetails(objSupplier);

            objSupplier1.DisplayDetails();



        }
    }
}
