﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HandlingEntities;
using HandlingExcepiton;

namespace DataAcess
{
    public class Guest
    {
        public static List<GuestEn> gL = new List<GuestEn>();

        public bool AddGuest(GuestEn nG)
        {
            bool guestAdded = false;
            try
            {
                gL.Add(nG);
                guestAdded = true;
            }
            catch (SystemException ex)
            {
                throw new Handlingexception(ex.Message);
            }
            return guestAdded;
        }

        public bool UpdateGuest(GuestEn updateGuest)
        {
            bool guestUpdated = false;
            try
            {
                for (int i = 0; i < gL.Count; i++)
                {
                    if (gL[i].GID == updateGuest.GID)
                    {
                        updateGuest.GName = gL[i].GName;
                        updateGuest.GContact= gL[i].GContact;
                        guestUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new Handlingexception(ex.Message);
            }
            return guestUpdated;
        }

        public bool DeleteGuest(int delGuest)
        {
            bool guestDeleted = false;
            try
            {
                GuestEn deleteGuest = gL.Find(guest => guest.GID == delGuest);

                if (deleteGuest != null)
                {
                    gL.Remove(deleteGuest);
                    guestDeleted = true;
                }
            }
            catch (SystemException ex)
            {
                throw new Handlingexception(ex.Message);
            }
            return guestDeleted;
        }

        public List<GuestEn> GetAllGuests()
        {
            return gL;
        }

        public GuestEn SearchGuest(int searchGuestID)
        {
            GuestEn sGuest = null;
            try
            {
                sGuest = gL.Find(guest => guest.GID == searchGuestID);
            }
            catch (SystemException ex)
            {
                throw new Handlingexception(ex.Message);
            }
            return sGuest;
        }
    }
}
