﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer;
using DataAcess;
using HandlingEntities;
using HandlingExcepiton;

namespace PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddGuest();
                        break;
                    case 2:
                        ListAllGuests();
                        break;
                    case 3:
                        SearchGuestByID();
                        break;
                    case 4:
                        UpdateGuest();
                        break;
                    case 5:
                        DeleteGuest();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != 0);
        }

        private static void DeleteGuest()
        {
            try
            {
                int deleteGuestID;
                Console.WriteLine("Enter GuestID to Delete:");
                deleteGuestID = Convert.ToInt32(Console.ReadLine());
                GuestEn deleteGuest = Bus.SearchGuestBL(deleteGuestID);
                if (deleteGuest != null)
                {
                    bool guestdeleted = Bus.DelGuestBL(deleteGuestID);
                    if (guestdeleted)
                        Console.WriteLine("Guest Deleted");
                    else
                        Console.WriteLine("Guest not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (Handlingexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateGuest()
        {
            try
            {
                int updateGuestID;
                Console.WriteLine("Enter GuestID to Update Details:");
                updateGuestID = Convert.ToInt32(Console.ReadLine());
                GuestEn updatedGuest = Bus.SearchGuestBL(updateGuestID);
                if (updatedGuest != null)
                {
                    Console.WriteLine("Update Guest Name :");
                    updatedGuest.GName = Console.ReadLine();
                    Console.WriteLine("Update PhoneNumber :");
                    updatedGuest.GContact = Console.ReadLine();
                    bool guestUpdated = Bus.UpdateGuestBL(updatedGuest);
                    if (guestUpdated)
                        Console.WriteLine("Guest Details Updated");
                    else
                        Console.WriteLine("Guest Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }


            }
            catch (Handlingexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchGuestByID()
        {
            try
            {
                int searchGuestID;
                Console.WriteLine("Enter GuestID to Search:");
                searchGuestID = Convert.ToInt32(Console.ReadLine());
                GuestEn searchGuest = Bus.SearchGuestBL(searchGuestID);
                if (searchGuest != null)
                {
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchGuest.GID, searchGuest.GName, searchGuest.GContact);                 
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }

            }
            catch (Handlingexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllGuests()
        {
            try
            {
                List<GuestEn> guestList = Bus.GetAllGuestsBL();
                if (guestList != null)
                {
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                    foreach (GuestEn guest in guestList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", guest.GID, guest.GName, guest.GContact);
                    }
                    Console.WriteLine("--------------------------------------------");

                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (Handlingexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddGuest()
        {
            try
            {
                GuestEn newGuest = new GuestEn();
                Console.WriteLine("Enter GuestID :");
                newGuest.GID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Guest Name :");
                newGuest.GName = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newGuest.GContact = Console.ReadLine();
                bool guestAdded = Bus.AddGuestBL(newGuest);
                if (guestAdded)
                    Console.WriteLine("Guest Added");
                else
                    Console.WriteLine("Guest not Added");
            }
            catch (Handlingexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n**Guest PhoneBook Menu**");
            Console.WriteLine("1. Add Guest");
            Console.WriteLine("2. List All Guests");
            Console.WriteLine("3. Search Guest by ID");
            Console.WriteLine("4. Update Guest");
            Console.WriteLine("5. Delete Guest");
            Console.WriteLine("6. Exit");
        }
    }
}
